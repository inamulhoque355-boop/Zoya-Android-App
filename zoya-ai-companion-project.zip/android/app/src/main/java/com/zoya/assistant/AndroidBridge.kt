package com.zoya.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.util.Locale

class AndroidBridge(
    private val activity: Activity,
    private val webView: WebView
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isTorchActive = false
    private var cameraIdWithFlash: String? = null
    private var cameraManager: CameraManager? = null

    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    init {
        initCamera()
        initTts()
        initSpeechRecognizer()
    }

    private fun initCamera() {
        try {
            cameraManager = activity.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            cameraManager?.let { manager ->
                for (id in manager.cameraIdList) {
                    val characteristics = manager.getCameraCharacteristics(id)
                    val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                    val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                    if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        cameraIdWithFlash = id
                        break
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Camera initialization failed: ${e.message}")
        }
    }

    private fun initTts() {
        try {
            textToSpeech = TextToSpeech(activity) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech?.let { tts ->
                        tts.language = Locale.US
                        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {
                                notifyJs("window.onAndroidSpeechTtsStart && window.onAndroidSpeechTtsStart();")
                            }

                            override fun onDone(utteranceId: String?) {
                                notifyJs("window.onAndroidSpeechTtsEnd && window.onAndroidSpeechTtsEnd();")
                            }

                            override fun onError(utteranceId: String?) {
                                notifyJs("window.onAndroidSpeechTtsEnd && window.onAndroidSpeechTtsEnd();")
                            }
                        })
                        isTtsReady = true
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "TTS init error: ${e.message}")
        }
    }

    private fun initSpeechRecognizer() {
        mainHandler.post {
            if (SpeechRecognizer.isRecognitionAvailable(activity)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            notifyJs("window.onAndroidSpeechReady && window.onAndroidSpeechReady();")
                        }

                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            isListening = false
                            notifyJs("window.onAndroidSpeechEnd && window.onAndroidSpeechEnd();")
                        }

                        override fun onError(error: Int) {
                            isListening = false
                            val message = "Speech recognition error code $error"
                            notifyJs("window.onAndroidSpeechError && window.onAndroidSpeechError('$message');")
                        }

                        override fun onResults(results: Bundle?) {
                            isListening = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val finalSpeech = matches?.firstOrNull() ?: ""
                            val safeText = finalSpeech.replace("'", "\\'").replace("\n", " ")
                            notifyJs("window.onAndroidSpeechResult && window.onAndroidSpeechResult('$safeText', true);")
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull() ?: ""
                            if (partial.isNotEmpty()) {
                                val safeText = partial.replace("'", "\\'").replace("\n", " ")
                                notifyJs("window.onAndroidSpeechResult && window.onAndroidSpeechResult('$safeText', false);")
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
        }
    }

    private fun notifyJs(script: String) {
        mainHandler.post {
            webView.evaluateJavascript(script, null)
        }
    }

    @JavascriptInterface
    fun isAndroidApp(): Boolean = true

    @JavascriptInterface
    fun getAndroidVersion(): Int = Build.VERSION.SDK_INT

    @JavascriptInterface
    fun startListening() {
        mainHandler.post {
            try {
                if (speechRecognizer != null && !isListening) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    }
                    speechRecognizer?.startListening(intent)
                    isListening = true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting voice recognition", e)
            }
        }
    }

    @JavascriptInterface
    fun stopListening() {
        mainHandler.post {
            try {
                if (isListening) {
                    speechRecognizer?.stopListening()
                    isListening = false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping voice recognition", e)
            }
        }
    }

    @JavascriptInterface
    fun speak(text: String, pitch: Float, rate: Float) {
        mainHandler.post {
            if (isTtsReady && textToSpeech != null) {
                try {
                    textToSpeech?.setPitch(if (pitch <= 0f) 1.0f else pitch)
                    textToSpeech?.setSpeechRate(if (rate <= 0f) 1.0f else rate)
                    textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoya_tts_${System.currentTimeMillis()}")
                } catch (e: Exception) {
                    Log.e(TAG, "TTS speak failed", e)
                }
            }
        }
    }

    @JavascriptInterface
    fun stopSpeech() {
        mainHandler.post {
            textToSpeech?.stop()
        }
    }

    @JavascriptInterface
    fun toggleTorch(): Boolean {
        return setTorch(!isTorchActive)
    }

    @JavascriptInterface
    fun setTorch(enable: Boolean): Boolean {
        val manager = cameraManager
        val camId = cameraIdWithFlash
        if (manager == null || camId == null) {
            return false
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setTorchMode(camId, enable)
                isTorchActive = enable
                true
            } else {
                false
            }
        } catch (e: CameraAccessException) {
            Log.e(TAG, "Camera flash access error", e)
            false
        }
    }

    @JavascriptInterface
    fun isTorchOn(): Boolean = isTorchActive

    @JavascriptInterface
    fun vibrate(milliseconds: Long) {
        try {
            val duration = if (milliseconds <= 0) 30L else milliseconds
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(duration)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration failed: ${e.message}")
        }
    }

    @JavascriptInterface
    fun getBatteryLevel(): Int {
        val batteryManager = activity.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    }

    @JavascriptInterface
    fun isBatteryCharging(): Boolean {
        val batteryManager = activity.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val status = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    @JavascriptInterface
    fun keepScreenAwake(enable: Boolean) {
        activity.runOnUiThread {
            if (enable) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    @JavascriptInterface
    fun launchApp(packageName: String, fallbackUri: String?): Boolean {
        return try {
            val pm = activity.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(launchIntent)
                true
            } else if (!fallbackUri.isNullOrEmpty()) {
                val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(viewIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app $packageName: ${e.message}")
            false
        }
    }

    @JavascriptInterface
    fun setWakeListeningEnabled(enable: Boolean): Boolean {
        return try {
            if (enable) {
                ZoyaWakeListeningService.startService(activity)
            } else {
                ZoyaWakeListeningService.stopService(activity)
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle wake listening service: ${e.message}", e)
            false
        }
    }

    @JavascriptInterface
    fun isWakeListeningActive(): Boolean {
        return ZoyaWakeListeningService.isServiceRunning
    }

    @JavascriptInterface
    fun shareText(title: String, text: String): Boolean {
        return try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_TITLE, title)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(shareIntent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open share sheet", e)
            false
        }
    }

    fun destroy() {
        try {
            if (isTorchActive) {
                setTorch(false)
            }
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error cleaning up bridge: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "AndroidBridge"
    }
}
