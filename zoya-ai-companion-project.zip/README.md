# Zoya — Personal AI Companion & Android Assistant

Zoya is a personal AI companion and Android voice assistant powered by Google Gemini. She features a real-time animated Anime Girl Avatar with lip-sync voice animations, hardware controls (flashlight, wake lock, battery), native Android app launching, and conversational intelligence across three distinct modes: **Girlfriend**, **Best Friend (Normal)**, and **Productivity Assistant**.

---

## Key Features

- **Interactive Anime Girl Avatar**:
  - Live lip-sync synchronized to speaking audio
  - Dynamic facial expressions: caring, happy, loving, amused, thoughtful, excited, supportive, focused, and friendly
  - Natural breathing and blinking physics
  - Direct speech controls with real-time feedback

- **Zero-Delay Voice & Speech**:
  - Voice input with speech silence auto-finalization
  - Natural Text-to-Speech synthesis with emotional pitch and rate modulation
  - Native Android `SpeechRecognizer` and `TextToSpeech` bridge for zero-latency execution in APK mode

- **Android System & Hardware Integration**:
  - Hardware flashlight / camera torch toggle
  - Native haptic feedback and vibrations
  - Real-time battery status and charging indicators
  - Screen wake-lock toggle for long hands-free conversations

- **Native App Launcher**:
  - Instant voice or tap launching of Android apps: YouTube, WhatsApp, Instagram, Spotify, Google Maps, Chrome, Camera, Phone Dialer, SMS Messages, and Settings

- **Flexible Deployment**:
  - **Web / PWA**: Runs on any modern browser or mobile PWA
  - **Android APK**: Complete Android Studio and Gradle project structure ready for GitHub CI/CD APK generation

---

## Project Structure

```
├── android/                   # Native Android Gradle Project
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── java/com/zoya/assistant/
│   │   │   │   ├── MainActivity.kt       # Modern WebView & permission handling
│   │   │   │   └── AndroidBridge.kt      # JavaScript-to-Android hardware bridge
│   │   │   ├── res/                      # Icons, styles, colors, security config
│   │   │   ├── assets/public/            # Bundled web assets for offline APK
│   │   │   └── AndroidManifest.xml       # Permissions, queries, and intents
│   │   ├── build.gradle                  # App build configuration (SDK 34)
│   │   └── proguard-rules.pro            # Bridge preservation rules
│   ├── gradle/wrapper/                   # Gradle 8.7 wrapper
│   ├── build.gradle                      # Root Gradle configuration
│   ├── settings.gradle                   # Module definitions
│   ├── gradlew / gradlew.bat             # Gradle wrapper executables
│   └── gradle.properties
├── .github/workflows/
│   └── build-apk.yml          # GitHub Actions workflow for automatic APK build
├── src/                       # Frontend React 19 + TypeScript application
│   ├── components/            # UI components (AnimeAvatar, HomeScreen, ChatScreen, etc.)
│   ├── utils/                 # Native bridges, speech synthesis, app launcher, commands
│   ├── App.tsx                # Central state orchestration & voice manager
│   ├── types.ts               # Type definitions
│   └── main.tsx               # Entry point
├── server.ts                  # Express backend with Gemini streaming & fallbacks
├── scripts/
│   └── copy-android-assets.js # Asset sync utility from Vite to Android
├── GITHUB_SETUP.md            # Detailed instructions for building APK on GitHub
└── package.json
```

---

## Quick Start (Web Development)

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build production bundle
npm run build
```

---

## Building the Android APK on GitHub

1. Push this repository to GitHub.
2. Navigate to the **Actions** tab in your GitHub repository.
3. Select the **Build Zoya Android APK** workflow and click **Run workflow** (or simply push to `main`).
4. Once completed, download the **Debug APK** or **Release APK** from the workflow artifacts.

For detailed local build instructions (via Android Studio or command line), see [GITHUB_SETUP.md](./GITHUB_SETUP.md).

---

## License

MIT
