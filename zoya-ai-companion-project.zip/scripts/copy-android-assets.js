// Node script to copy built Vite web assets into Android project assets
import fs from 'fs';
import path from 'path';

const srcDir = path.resolve(process.cwd(), 'dist');
const destDir = path.resolve(process.cwd(), 'android/app/src/main/assets/public');

function copyRecursiveSync(src, dest) {
  const exists = fs.existsSync(src);
  const stats = exists && fs.statSync(src);
  const isDirectory = exists && stats.isDirectory();

  if (isDirectory) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    fs.readdirSync(src).forEach((childItemName) => {
      copyRecursiveSync(path.join(src, childItemName), path.join(dest, childItemName));
    });
  } else if (exists) {
    // Only copy client files, skip server.cjs if present
    if (src.endsWith('server.cjs') || src.endsWith('server.cjs.map')) return;
    const parentDir = path.dirname(dest);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.copyFileSync(src, dest);
  }
}

if (!fs.existsSync(srcDir)) {
  console.error('Error: "dist" folder not found. Run "npm run build" first.');
  process.exit(1);
}

// Clean old assets
if (fs.existsSync(destDir)) {
  fs.rmSync(destDir, { recursive: true, force: true });
}
fs.mkdirSync(destDir, { recursive: true });

console.log(`Copying web assets from ${srcDir} to ${destDir}...`);
copyRecursiveSync(srcDir, destDir);
console.log('Successfully synchronized Android web assets!');
