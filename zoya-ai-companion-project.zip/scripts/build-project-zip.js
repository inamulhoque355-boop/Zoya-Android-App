import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const zip = new JSZip();

const IGNORE_DIRS = new Set(['node_modules', '.git', 'dist', '.cache', '.turbo']);
const IGNORE_FILES = new Set(['.DS_Store', 'zoya-project-package.zip']);

function addDirToZip(dirPath, zipFolder) {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (IGNORE_DIRS.has(item) || IGNORE_FILES.has(item)) continue;
    // Don't zip the output zip itself if inside public
    if (item.endsWith('.zip')) continue;

    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      const subFolder = zipFolder.folder(item);
      addDirToZip(fullPath, subFolder);
    } else {
      const content = fs.readFileSync(fullPath);
      zipFolder.file(item, content);
    }
  }
}

async function buildZip() {
  console.log('Generating complete Zoya AI Project & APK Package ZIP...');
  addDirToZip('.', zip);

  // Add APK & Export Guide into the ZIP root for immediate user convenience
  const apkGuide = `# Zoya AI Companion - Android APK & Project Deployment Guide

This package contains the complete, updated source code and Android native project structure for Zoya AI Companion.

## Quick Start (Run Locally)
1. Install dependencies:
   npm install
2. Start development server:
   npm run dev
3. Open in browser at http://localhost:3000

## How to Build the Android APK

### Option 1: Using Android Studio (Native Gradle)
1. Open the \`android\` directory in Android Studio.
2. Allow Gradle to sync dependencies.
3. In Android Studio, go to:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
4. Once built, find your APK at:
   \`android/app/build/outputs/apk/debug/app-debug.apk\`

### Option 2: Using Command Line (Gradle Wrapper)
\`\`\`bash
cd android
./gradlew assembleDebug
\`\`\`
The APK will be generated at \`android/app/build/outputs/apk/debug/app-debug.apk\`.

### Option 3: Instant Android PWA / APK (via Bubblewrap)
\`\`\`bash
npm run build
npx @bubblewrap/cli init --manifest=public/manifest.json
npx @bubblewrap/cli build
\`\`\`

## GitHub Deployment
1. Initialize repository:
   \`git init && git add . && git commit -m "Initial commit"\`
2. Push to GitHub:
   \`git remote add origin <your-repo-url>\`
   \`git push -u origin main\`
`;

  zip.file('APK_BUILD_GUIDE.md', apkGuide);

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const outputPath = path.resolve('public/zoya-project-package.zip');
  fs.writeFileSync(outputPath, buffer);
  console.log(`Package ZIP created successfully at ${outputPath} (${(buffer.length / (1024 * 1024)).toFixed(2)} MB)`);
}

buildZip().catch(console.error);
