# Zoya AI Companion - Android APK & Project Deployment Guide

This package contains the complete, updated source code and Android native project structure for Zoya AI Companion.

## Quick Start (Run Locally)
1. Install dependencies:
   npm install
2. Start development server:
   npm run dev
3. Open in browser at http://localhost:3000

## How to Build the Android APK

### Option 1: Using Android Studio (Native Gradle)
1. Open the `android` directory in Android Studio.
2. Allow Gradle to sync dependencies.
3. In Android Studio, go to:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
4. Once built, find your APK at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Using Command Line (Gradle Wrapper)
```bash
cd android
./gradlew assembleDebug
```
The APK will be generated at `android/app/build/outputs/apk/debug/app-debug.apk`.

### Option 3: Instant Android PWA / APK (via Bubblewrap)
```bash
npm run build
npx @bubblewrap/cli init --manifest=public/manifest.json
npx @bubblewrap/cli build
```

## GitHub Deployment
1. Initialize repository:
   `git init && git add . && git commit -m "Initial commit"`
2. Push to GitHub:
   `git remote add origin <your-repo-url>`
   `git push -u origin main`
