# Transferring Zoya to GitHub & Building the Android APK

This guide provides step-by-step instructions for manually transferring the Zoya AI Assistant project from Google AI Studio to GitHub, and building the Android APK directly on GitHub or locally.

---

## 1. Transferring Files to GitHub

### Option A: Via Git CLI
1. Initialize a git repository locally:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Zoya AI Assistant Android Project"
   ```
2. Create a new repository on [GitHub](https://github.com/new).
3. Connect your local repository and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

### Option B: Export / Download ZIP
1. In Google AI Studio, click the settings/download icon to export the project ZIP.
2. Extract the files on your computer.
3. Upload the files to your GitHub repository.

---

## 2. Automatic APK Build via GitHub Actions (Zero Setup Required)

This repository includes a pre-configured GitHub Actions workflow located at `.github/workflows/build-apk.yml`.

Whenever you push to `main` (or click **Run workflow** in the GitHub **Actions** tab):
1. GitHub runners automatically install Node.js dependencies and build the web assets.
2. Web assets are bundled into `android/app/src/main/assets/public/`.
3. Java 17 and Gradle build both the **Debug APK** and **Release APK**.
4. The generated APKs are uploaded as artifacts under the workflow run:
   - **`Zoya-Assistant-Debug-APK`**
   - **`Zoya-Assistant-Release-APK`**
5. Download the APK directly to your Android device, enable "Install unknown apps" in Android settings, and install!

---

## 3. Building Locally with Android Studio

1. Open **Android Studio**.
2. Select **Open** and choose the `android` folder in this project:
   ```
   zoya-assistant/android
   ```
3. Android Studio will automatically recognize the Gradle project and download dependencies.
4. Before building, compile and sync the web assets if you have made changes:
   ```bash
   npm run build:android
   ```
5. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)** in Android Studio, or connect your Android device and click the green **Run** button.

---

## 4. Building Locally via Terminal

If you have Java 17 and Android SDK installed on your system:
```bash
# 1. Install Node dependencies and bundle web assets
npm install
npm run build:android

# 2. Build Debug APK using Gradle Wrapper
cd android
chmod +x gradlew
./gradlew assembleDebug

# The APK will be generated at:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 5. Standalone APK Mode & Gemini API Configuration

Zoya is designed to run in two modes:
1. **Full-Stack Mode (Cloud Run / Node.js)**: Uses `server.ts` to proxy Gemini streaming requests.
2. **Standalone Android APK Mode**: Runs directly on the device using Android's native WebView and local bundled assets.
   - When running in standalone APK mode, open **Settings** in the bottom navigation bar of the Zoya app.
   - Enter your personal Google Gemini API key (obtainable for free at [Google AI Studio](https://aistudio.google.com/)).
   - Zoya will converse with you directly using Google's Gemini models with emotion detection, facial animation, and speech synthesis.

---

## 6. Native Android Capabilities

When running as an Android APK, Zoya communicates with Android's native APIs through the `AndroidBridge` interface:
- **Speech Recognition**: Android Native `SpeechRecognizer` (fast voice transcription)
- **Text-to-Speech**: Android Native `TextToSpeech` engine (custom pitch and speed)
- **Flashlight / Torch**: `CameraManager` hardware control
- **Haptic Vibration**: `Vibrator` / `VibrationEffect`
- **Battery Status**: Real-time battery percentage and charging state via `BatteryManager`
- **Wake Lock**: Keeps the screen awake during active conversation
- **App Launcher**: Launches Android installed apps (YouTube, WhatsApp, Instagram, Spotify, Google Maps, Chrome, Camera, Dialer, Messages) using native Android intents.
