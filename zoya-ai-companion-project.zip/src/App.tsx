import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidNavBar, NavTab } from './components/AndroidNavBar';
import { HomeScreen } from './components/HomeScreen';
import { ChatScreen } from './components/ChatScreen';
import { AssistantScreen } from './components/AssistantScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { AppSettings, ChatMessage, CompanionMode, EmotionType, WeatherData } from './types';
import { speechController, createSpeechRecognizer } from './utils/speech';
import { executeAndroidAction, ANDROID_ACTIONS } from './utils/androidActions';
import { matchInstantCommand } from './utils/commandMatcher';
import { findAndroidApp, launchAndroidApp, launchYouTubeWithSong } from './utils/appLauncher';
import { promptFilePicker } from './utils/fileCodingAssistant';
import { callGeminiDirect } from './utils/geminiDirect';
import { wakeWordManager } from './utils/wakeWord';
import { detectContextualEmotion } from './utils/emotionDetector';

const STORAGE_KEY = 'zoya_app_settings_v1';
const CHAT_HISTORY_KEY = 'zoya_chat_history_v1';

const DEFAULT_SETTINGS: AppSettings = {
  userName: 'Inamul',
  zoyaName: 'Zoya',
  geminiApiKey: '',
  selectedMode: 'girlfriend',
  language: 'auto',
  voiceSettings: {
    autoSpeak: true,
    voiceURI: '',
    pitch: 1.15,
    rate: 0.98,
    hapticFeedback: true,
    wakeListening: false,
    language: 'auto',
  },
  permissions: {
    microphone: false,
    speech: true,
    notifications: false,
    wakeLock: false,
    geolocation: false,
  },
};

export default function App() {
  // 1. Settings State
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // If previous saved settings had the old 1.1 / 1.05 values, update to the new soft feminine baseline
        const voiceSettings = {
          ...DEFAULT_SETTINGS.voiceSettings,
          ...(parsed.voiceSettings || {}),
        };
        if (voiceSettings.pitch === 1.1) {
          voiceSettings.pitch = DEFAULT_SETTINGS.voiceSettings.pitch;
        }
        if (voiceSettings.rate === 1.05) {
          voiceSettings.rate = DEFAULT_SETTINGS.voiceSettings.rate;
        }
        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          voiceSettings,
        };
      }
    } catch (e) {
      console.warn('Failed to load settings from storage', e);
    }
    return DEFAULT_SETTINGS;
  });

  const [hasServerKey, setHasServerKey] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<NavTab>('home');

  // 2. Chat & AI State
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(CHAT_HISTORY_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load chat history', e);
    }
    // Default initial greeting message
    return [
      {
        id: 'init-1',
        role: 'assistant',
        text: `Hey Inamul! I'm Zoya, your personal AI companion. I'm right here by your side. Say the name of any app like YouTube, Instagram, WhatsApp, or ask me anything!`,
        timestamp: Date.now(),
        emotion: 'caring',
      },
    ];
  });

  const [currentEmotion, setCurrentEmotion] = useState<EmotionType>('caring');
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [isSpeakingState, setIsSpeakingState] = useState<boolean>(false);
  const [currentSpeechText, setCurrentSpeechText] = useState<string>('');

  // 3. Voice Recognition State
  const [isListening, setIsListening] = useState<boolean>(false);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const speechRecognizerRef = useRef<any>(null);
  const hasTriggeredInterimRef = useRef<boolean>(false);

  // Synchronize speaking state with global speechController
  useEffect(() => {
    const unsub = speechController.onSpeakingChange((speaking) => {
      setIsSpeakingState(speaking);
      if (!speaking) {
        setCurrentlySpeakingId(null);
        setCurrentSpeechText('');
      }
    });
    return unsub;
  }, []);

  // 4. Weather State
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isWeatherLoading, setIsWeatherLoading] = useState<boolean>(false);
  const [wakeStatusMessage, setWakeStatusMessage] = useState<string>('');

  // Toggle Wake Listening
  const handleToggleWakeListening = useCallback(() => {
    const nextState = !settings.voiceSettings.wakeListening;
    const updated: AppSettings = {
      ...settings,
      voiceSettings: {
        ...settings.voiceSettings,
        wakeListening: nextState,
      },
    };
    handleSaveSettings(updated);
  }, [settings]);

  // Save settings when changed
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
    } catch (e) {
      console.warn('Failed to save settings', e);
    }
  };

  // Save chat messages
  useEffect(() => {
    try {
      localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(messages.slice(-30)));
    } catch (e) {
      console.warn('Failed to save chat', e);
    }
  }, [messages]);

  // Check server status on mount
  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        setHasServerKey(Boolean(data.hasServerKey));
      })
      .catch(() => setHasServerKey(false));

    // Listen for PWA beforeinstallprompt
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      (window as any).deferredPrompt = e;
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Fetch Weather
  const fetchWeather = useCallback(async () => {
    setIsWeatherLoading(true);
    try {
      let lat = '37.7749';
      let lon = '-122.4194';
      let cityName = 'Local Forecast';

      if (navigator.geolocation) {
        try {
          const pos: any = await new Promise((res, rej) => {
            navigator.geolocation.getCurrentPosition(res, rej, { timeout: 4000 });
          });
          lat = pos.coords.latitude.toFixed(4);
          lon = pos.coords.longitude.toFixed(4);
          cityName = 'Current Location';
        } catch {
          // fallback location
        }
      }

      const res = await fetch(`/api/weather?lat=${lat}&lon=${lon}&city=${encodeURIComponent(cityName)}`);
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data?.current) {
          const current = json.data.current;
          const code = current.weather_code || 0;
          let cond = 'Clear';
          if (code >= 1 && code <= 3) cond = 'Partly Cloudy';
          else if (code >= 45 && code <= 48) cond = 'Foggy';
          else if (code >= 51 && code <= 67) cond = 'Rainy';
          else if (code >= 71 && code <= 86) cond = 'Snowy';
          else if (code >= 95) cond = 'Thunderstorm';

          setWeather({
            temp: current.temperature_2m || 22,
            feelsLike: current.apparent_temperature || 21,
            humidity: current.relative_humidity_2m || 55,
            windSpeed: current.wind_speed_10m || 10,
            condition: cond,
            weatherCode: code,
            isDay: Boolean(current.is_day),
            city: cityName,
          });
        }
      }
    } catch (e) {
      console.warn('Weather fetch error:', e);
    } finally {
      setIsWeatherLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeather();
  }, [fetchWeather]);

  // Voice playback for a specific message
  const handleSpeakMessage = (msg: ChatMessage) => {
    setCurrentlySpeakingId(msg.id);
    setCurrentSpeechText(msg.text);
    speechController.speak(
      msg.text,
      settings.voiceSettings,
      msg.emotion || currentEmotion,
      () => {
        setCurrentlySpeakingId(null);
        setCurrentSpeechText('');
      },
      () => {
        setCurrentlySpeakingId(null);
        setCurrentSpeechText('');
      },
      settings.language
    );
  };

  // Voice playback for text (e.g. greeting or manual speech trigger)
  const handleSpeakText = (text: string) => {
    speechController.prewarm();
    setCurrentlySpeakingId('speech-text');
    setCurrentSpeechText(text);
    speechController.speak(
      text,
      settings.voiceSettings,
      currentEmotion,
      () => {
        setCurrentlySpeakingId(null);
        setCurrentSpeechText('');
      },
      () => {
        setCurrentlySpeakingId(null);
        setCurrentSpeechText('');
      },
      settings.language
    );
  };

  const handleStopSpeech = () => {
    speechController.stop();
    setCurrentlySpeakingId(null);
    setCurrentSpeechText('');
  };

  // High-Performance Message Processing (Local Instant Action + Streaming AI)
  const handleSendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    // Prewarm speech engine on mobile
    speechController.prewarm();

    // Stop speaking prior speech
    handleStopSpeech();

    // Haptic feedback
    if (settings.voiceSettings.hapticFeedback && navigator.vibrate) {
      navigator.vibrate(30);
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);

    // 1. FAST-PATH: Instant Local Command & App Matcher (<5ms latency)
    // Matches commands like "YouTube", "open WhatsApp", "Instagram", "Flashlight", "Camera", etc.
    const instantMatch = matchInstantCommand(
      trimmed,
      settings.selectedMode,
      settings.userName,
      settings.zoyaName
    );

    if (instantMatch) {
      const zoyaEmotion = instantMatch.emotion || 'focused';
      setCurrentEmotion(zoyaEmotion);

      // Execute the native Android action immediately
      if (instantMatch.execute) {
        instantMatch.execute().catch((e) => console.warn('Instant command execution error:', e));
      }

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        text: instantMatch.replyText,
        timestamp: Date.now(),
        emotion: zoyaEmotion,
        actionTriggered: instantMatch.actionId,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Speak immediately
      if (settings.voiceSettings.autoSpeak) {
        setCurrentlySpeakingId(assistantMsg.id);
        setCurrentSpeechText(assistantMsg.text);
        speechController.speak(
          assistantMsg.text,
          settings.voiceSettings,
          zoyaEmotion,
          () => {
            setCurrentlySpeakingId(null);
            setCurrentSpeechText('');
          },
          () => {
            setCurrentlySpeakingId(null);
            setCurrentSpeechText('');
          }
        );
      }
      return;
    }

    // 2. SLOW-PATH: Streaming Gemini AI Response for open-ended conversation
    setIsThinking(true);
    const assistantMsgId = `assistant-${Date.now()}`;
    let accumulatedText = '';
    let hasStartedSpoken = false;

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: messages.slice(-8),
          mode: settings.selectedMode,
          userName: settings.userName,
          zoyaName: settings.zoyaName,
          customApiKey: settings.geminiApiKey,
          deviceContext: `Current time: ${new Date().toLocaleTimeString()}, Weather: ${weather?.temp || 22}°C ${weather?.condition || 'Clear'}`,
          language: settings.language,
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Streaming connection failed, trying fallback...');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      const contextualEmotion = detectContextualEmotion(trimmed, settings.selectedMode, currentEmotion);
      let finalEmotion: EmotionType = contextualEmotion;
      setCurrentEmotion(contextualEmotion);
      let finalAction: string | null = null;

      // Temporary placeholder message to stream into
      setMessages((prev) => [
        ...prev,
        {
          id: assistantMsgId,
          role: 'assistant',
          text: '',
          timestamp: Date.now(),
          emotion: finalEmotion,
        },
      ]);
      setIsThinking(false);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (trimmedLine.startsWith('data: ')) {
            try {
              const data = JSON.parse(trimmedLine.slice(6));
              if (data.chunk) {
                accumulatedText += data.chunk;

                // Strip meta tags for UI display
                const cleanSoFar = accumulatedText
                  .replace(/\[emotion:\s*[a-zA-Z_]+\]/gi, '')
                  .replace(/\[action:\s*[a-zA-Z_]+\]/gi, '');

                setMessages((prev) =>
                  prev.map((m) => (m.id === assistantMsgId ? { ...m, text: cleanSoFar, emotion: finalEmotion } : m))
                );

                // Progressive speech synthesis: Start speaking on first completed sentence!
                if (
                  settings.voiceSettings.autoSpeak &&
                  !hasStartedSpoken &&
                  cleanSoFar.length > 20 &&
                  /[.!?]\s*$/.test(cleanSoFar)
                ) {
                  hasStartedSpoken = true;
                  setCurrentlySpeakingId(assistantMsgId);
                  setCurrentSpeechText(cleanSoFar);
                  speechController.speak(
                    cleanSoFar,
                    settings.voiceSettings,
                    finalEmotion,
                    () => {
                      setCurrentlySpeakingId(null);
                      setCurrentSpeechText('');
                    },
                    () => {
                      setCurrentlySpeakingId(null);
                      setCurrentSpeechText('');
                    },
                    settings.language
                  );
                }
              }

              if (data.done) {
                if (data.emotion) {
                  finalEmotion = data.emotion as EmotionType;
                  setCurrentEmotion(finalEmotion);
                }
                if (data.action) {
                  finalAction = data.action;
                  handleExecuteAction(data.action);
                }
              }
            } catch (jsonErr) {
              console.warn('SSE JSON parse error:', jsonErr);
            }
          }
        }
      }

      // Final clean up and speak remaining text if not yet started
      const finalClean = accumulatedText
        .replace(/\[emotion:\s*[a-zA-Z_]+\]/gi, '')
        .replace(/\[action:\s*[a-zA-Z_]+\]/gi, '')
        .trim();

      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMsgId
            ? { ...m, text: finalClean || "I'm right here with you.", emotion: finalEmotion, actionTriggered: finalAction || undefined }
            : m
        )
      );

      if (settings.voiceSettings.autoSpeak && !hasStartedSpoken && finalClean) {
        setCurrentlySpeakingId(assistantMsgId);
        setCurrentSpeechText(finalClean);
        speechController.speak(
          finalClean,
          settings.voiceSettings,
          finalEmotion,
          () => {
            setCurrentlySpeakingId(null);
            setCurrentSpeechText('');
          },
          () => {
            setCurrentlySpeakingId(null);
            setCurrentSpeechText('');
          },
          settings.language
        );
      }
    } catch (err: any) {
      console.warn('Stream failed, falling back to standard /api/chat:', err);

      // Fallback to standard /api/chat
      try {
        const fallbackRes = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: trimmed,
            history: messages.slice(-6),
            mode: settings.selectedMode,
            userName: settings.userName,
            zoyaName: settings.zoyaName,
            customApiKey: settings.geminiApiKey,
            deviceContext: `Current time: ${new Date().toLocaleTimeString()}, Weather: ${weather?.temp || 22}°C ${weather?.condition || 'Clear'}`,
            language: settings.language,
          }),
        });

        const data = await fallbackRes.json();
        if (!fallbackRes.ok) throw new Error(data.error || 'Failed to connect to Zoya');

        const zoyaEmotion: EmotionType = data.emotion || 'caring';
        setCurrentEmotion(zoyaEmotion);

        const assistantMsg: ChatMessage = {
          id: assistantMsgId,
          role: 'assistant',
          text: data.reply || "I'm right here with you.",
          timestamp: Date.now(),
          emotion: zoyaEmotion,
          actionTriggered: data.action || undefined,
        };

        setMessages((prev) => {
          const filtered = prev.filter((m) => m.id !== assistantMsgId);
          return [...filtered, assistantMsg];
        });

        if (settings.voiceSettings.autoSpeak) {
          setCurrentlySpeakingId(assistantMsg.id);
          setCurrentSpeechText(assistantMsg.text);
          speechController.speak(
            assistantMsg.text,
            settings.voiceSettings,
            zoyaEmotion,
            () => {
              setCurrentlySpeakingId(null);
              setCurrentSpeechText('');
            },
            () => {
              setCurrentlySpeakingId(null);
              setCurrentSpeechText('');
            },
            settings.language
          );
        }

        if (data.action) {
          handleExecuteAction(data.action);
        }
      } catch (fallbackErr: any) {
        // Standalone Android APK Mode or Direct Gemini Fallback
        if (settings.geminiApiKey) {
          try {
            const directResult = await callGeminiDirect(
              settings.geminiApiKey,
              trimmed,
              messages.slice(-6),
              settings.selectedMode,
              settings.userName,
              settings.zoyaName,
              `Current time: ${new Date().toLocaleTimeString()}, Weather: ${weather?.temp || 22}°C ${weather?.condition || 'Clear'}`
            );

            setCurrentEmotion(directResult.emotion);
            const directMsg: ChatMessage = {
              id: assistantMsgId,
              role: 'assistant',
              text: directResult.reply,
              timestamp: Date.now(),
              emotion: directResult.emotion,
              actionTriggered: directResult.action,
            };

            setMessages((prev) => {
              const filtered = prev.filter((m) => m.id !== assistantMsgId);
              return [...filtered, directMsg];
            });

            if (settings.voiceSettings.autoSpeak) {
              setCurrentlySpeakingId(directMsg.id);
              setCurrentSpeechText(directMsg.text);
              speechController.speak(
                directMsg.text,
                settings.voiceSettings,
                directResult.emotion,
                () => {
                  setCurrentlySpeakingId(null);
                  setCurrentSpeechText('');
                },
                () => {
                  setCurrentlySpeakingId(null);
                  setCurrentSpeechText('');
                }
              );
            }

            if (directResult.action) {
              handleExecuteAction(directResult.action);
            }
            return;
          } catch (directErr: any) {
            console.warn('Direct Gemini API also failed:', directErr);
          }
        }

        const isStandalone = typeof window !== 'undefined' && Boolean((window as any).Android);
        const errorText = isStandalone && !settings.geminiApiKey
          ? "Welcome to Zoya on Android! To chat in standalone APK mode, please open Settings and enter your free Google Gemini API key."
          : `I had trouble connecting with Gemini AI: ${fallbackErr.message || 'Please check your connection or API key in Settings.'}`;

        const errorMsg: ChatMessage = {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: errorText,
          timestamp: Date.now(),
          emotion: 'thoughtful',
        };
        setMessages((prev) => [...prev, errorMsg]);
      }
    } finally {
      setIsThinking(false);
    }
  };

  // Continuous Background & Foreground Wake Word Detection ("Hey Zoya")
  useEffect(() => {
    const isWakeEnabled = Boolean(settings.voiceSettings.wakeListening);

    wakeWordManager.setEnabled(
      isWakeEnabled,
      (detectedQuery: string) => {
        console.log('Wake word trigger received:', detectedQuery);

        if (detectedQuery && detectedQuery.trim().length > 0) {
          // Rapid one-shot: user said "Hey Zoya, open camera" or "Hey Zoya, what is the weather?"
          handleSendMessage(detectedQuery);
        } else {
          // User said "Hey Zoya" -> Immediate conversational response + activate speech recognizer
          const greeting =
            settings.selectedMode === 'girlfriend'
              ? `Yes ${settings.userName}? I'm right here listening!`
              : `Yes ${settings.userName}? How can I help you?`;

          handleSpeakText(greeting);

          // Activate voice recognition immediately after brief chime/acknowledgement
          setTimeout(() => {
            if (!isListening) {
              handleToggleVoice();
            }
          }, 950);
        }
      },
      (isActive, err) => {
        if (err) {
          setWakeStatusMessage(err);
        } else {
          setWakeStatusMessage(isActive ? 'Active' : '');
        }
      }
    );

    return () => {
      wakeWordManager.setEnabled(false, () => {});
    };
  }, [
    settings.voiceSettings.wakeListening,
    settings.selectedMode,
    settings.userName,
    isListening,
  ]);

  // Pause wake listener while speaking or during active microphone listening
  useEffect(() => {
    const shouldPause = Boolean(isSpeakingState || currentlySpeakingId || isListening);
    wakeWordManager.pauseForActiveSpeech(shouldPause);
  }, [isSpeakingState, currentlySpeakingId, isListening]);

  // Ultra-Fast Speech Recognition Controller
  const handleToggleVoice = () => {
    speechController.prewarm();

    if (isListening) {
      speechRecognizerRef.current?.stop();
      setIsListening(false);
      setInterimTranscript('');
      hasTriggeredInterimRef.current = false;
      return;
    }

    handleStopSpeech();
    hasTriggeredInterimRef.current = false;

    const recognizer = createSpeechRecognizer({
      silenceTimeoutMs: 650, // fast silence auto-commit
      language: settings.language,
      onStart: () => {
        setIsListening(true);
        hasTriggeredInterimRef.current = false;
        if (settings.voiceSettings.hapticFeedback && navigator.vibrate) {
          navigator.vibrate(35);
        }
      },
      onResult: (transcript, isFinal) => {
        if (hasTriggeredInterimRef.current) return;

        // Check if interim transcript already contains an unambiguous app or command
        // (e.g. user said "YouTube" or "open WhatsApp")
        if (!isFinal && transcript.trim().length >= 3) {
          const instantEarly = matchInstantCommand(
            transcript,
            settings.selectedMode,
            settings.userName,
            settings.zoyaName
          );

          if (instantEarly) {
            hasTriggeredInterimRef.current = true;
            setIsListening(false);
            setInterimTranscript('');
            try {
              recognizer.stop();
            } catch {
              // ignore
            }
            handleSendMessage(transcript);
            return;
          }
        }

        if (isFinal) {
          hasTriggeredInterimRef.current = true;
          setIsListening(false);
          setInterimTranscript('');
          handleSendMessage(transcript);
        } else {
          setInterimTranscript(transcript);
        }
      },
      onEnd: () => {
        setIsListening(false);
        hasTriggeredInterimRef.current = false;
      },
      onError: (err) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
        hasTriggeredInterimRef.current = false;
      },
    });

    if (recognizer) {
      speechRecognizerRef.current = recognizer;
      try {
        recognizer.start();
      } catch (e) {
        console.warn('Failed to start recognizer', e);
        setIsListening(false);
      }
    } else {
      alert("Microphone voice recognition is not supported or was blocked on this browser. You can still type in Chat!");
    }
  };

  // Execute an Android action triggered from Chat or quick prompt
  const handleExecuteAction = (actionKey: string) => {
    // Check if it's a YouTube play song action
    if (actionKey.startsWith('youtube_play:')) {
      const songQuery = actionKey.replace('youtube_play:', '');
      launchYouTubeWithSong(songQuery);
      return;
    }

    if (actionKey === 'youtube_play' || actionKey === 'open_youtube') {
      const yt = findAndroidApp('youtube');
      if (yt) launchAndroidApp(yt);
      return;
    }

    // Check if it's file picker
    if (actionKey === 'file_picker' || actionKey === 'open_file') {
      promptFilePicker('*/*', (info, textContent) => {
        if (info && textContent) {
          handleSendMessage(`I selected file "${info.name}". Can you help analyze this code/content?`);
        }
      });
      return;
    }

    // Check if it's an app launcher action
    if (actionKey.startsWith('app_')) {
      const appId = actionKey.replace('app_', '');
      const app = findAndroidApp(appId);
      if (app) {
        launchAndroidApp(app);
        return;
      }
    }

    const actionMapping: Record<string, string> = {
      open_camera: 'camera',
      open_dialer: 'dialer',
      open_sms: 'sms',
      open_maps: 'maps',
      open_email: 'email',
      open_browser: 'search',
      open_clock: 'clock',
      open_calculator: 'calculator',
      toggle_torch: 'torch',
      wake_lock: 'wake_lock',
      check_battery: 'battery_status',
    };

    const mappedKey = actionMapping[actionKey.toLowerCase()] || actionKey;
    const directApp = findAndroidApp(mappedKey);
    if (directApp) {
      launchAndroidApp(directApp);
      return;
    }

    const action = ANDROID_ACTIONS.find(
      (a) => a.id.toLowerCase() === mappedKey.toLowerCase() || mappedKey.toLowerCase().includes(a.id)
    );
    if (action) {
      executeAndroidAction(action);
    }
  };

  // Quick prompt selected from HomeScreen
  const handleSelectPrompt = (prompt: string) => {
    setActiveTab('chat');
    handleSendMessage(prompt);
  };

  // Clear Chat History
  const handleClearMessages = () => {
    setMessages([
      {
        id: `init-${Date.now()}`,
        role: 'assistant',
        text: `Chat cleared! I'm ready whenever you'd like to talk or launch an app.`,
        timestamp: Date.now(),
        emotion: settings.selectedMode === 'girlfriend' ? 'caring' : 'friendly',
      },
    ]);
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col justify-between max-w-md mx-auto shadow-2xl border-x border-slate-800/40 relative font-sans">
      {/* Top Android Status Bar */}
      <AndroidStatusBar
        isListening={isListening}
        isSpeaking={Boolean(currentlySpeakingId || isSpeakingState)}
      />

      {/* Main Screen Content */}
      <main className="flex-1 overflow-y-auto pt-2">
        {activeTab === 'home' && (
          <HomeScreen
            settings={settings}
            onUpdateMode={(mode) => handleSaveSettings({ ...settings, selectedMode: mode })}
            onStartVoice={handleToggleVoice}
            isListening={isListening}
            isSpeaking={Boolean(currentlySpeakingId || isSpeakingState)}
            isThinking={isThinking}
            currentEmotion={currentEmotion}
            onSelectPrompt={handleSelectPrompt}
            onNavigateTab={setActiveTab}
            weather={weather}
            onRefreshWeather={fetchWeather}
            isWeatherLoading={isWeatherLoading}
            currentSpeechText={currentSpeechText}
            onSpeakText={handleSpeakText}
            onStopSpeech={handleStopSpeech}
            isWakeListening={Boolean(settings.voiceSettings.wakeListening)}
            onToggleWakeListening={handleToggleWakeListening}
            wakeStatusMessage={wakeStatusMessage}
            onEmotionChange={(emo) => setCurrentEmotion(emo)}
            onUpdateLanguage={(lang) => handleSaveSettings({ ...settings, language: lang })}
          />
        )}

        {activeTab === 'chat' && (
          <ChatScreen
            messages={messages}
            onSendMessage={handleSendMessage}
            onClearMessages={handleClearMessages}
            isListening={isListening}
            onToggleVoice={handleToggleVoice}
            interimTranscript={interimTranscript}
            isThinking={isThinking}
            settings={settings}
            onSpeakMessage={handleSpeakMessage}
            onStopSpeech={handleStopSpeech}
            currentlySpeakingId={currentlySpeakingId}
            onExecuteAction={handleExecuteAction}
          />
        )}

        {activeTab === 'assistant' && (
          <AssistantScreen
            onSendMessage={handleSendMessage}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsScreen
            settings={settings}
            onSaveSettings={handleSaveSettings}
            hasServerKey={hasServerKey}
          />
        )}
      </main>

      {/* Bottom Android Navigation Bar */}
      <AndroidNavBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isListening={isListening}
        onToggleVoice={handleToggleVoice}
      />
    </div>
  );
}
