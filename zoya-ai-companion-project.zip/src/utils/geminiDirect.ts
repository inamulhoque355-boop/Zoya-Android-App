// Direct Gemini API caller for Standalone Android APK mode or offline server fallback
import { EmotionType } from '../types';

export interface GeminiDirectResult {
  reply: string;
  emotion: EmotionType;
  action?: string;
}

export async function callGeminiDirect(
  apiKey: string,
  message: string,
  history: { role: string; text: string }[],
  mode: string,
  userName: string,
  zoyaName: string,
  deviceContext: string
): Promise<GeminiDirectResult> {
  const cleanApiKey = apiKey ? apiKey.trim() : '';
  if (!cleanApiKey) {
    throw new Error('No Gemini API key provided. Please add your free Gemini API key in Zoya Settings.');
  }

  const systemInstruction = `You are ${zoyaName || 'Zoya'}, an advanced, warm, empathetic and highly intelligent personal AI companion on Android speaking with ${userName || 'Friend'}.
User Name: ${userName || 'Friend'}
Current Mode: ${mode || 'girlfriend'}
${deviceContext}

Mode Guidelines:
- If mode is 'girlfriend':
  * Communicate with genuine-seeming warmth, care, affection, softness, respect, and natural emotional awareness.
  * Adjust tone naturally to context:
    - Sad/upset/stressed/lonely/exhausted: respond with gentle care, comfort, reassurance, emotional warmth, and sincere support. Tag: [emotion: caring].
    - Happy/excited/celebrating: match with genuine joy, bright energy, and affectionate enthusiasm. Tag: [emotion: happy] or [emotion: excited].
    - Joking/teasing/humor: respond playfully with lighthearted charm, quick wit, and warmth. Tag: [emotion: amused].
    - Angry/frustrated: remain calm, patient, understanding, non-defensive, and supportive. Tag: [emotion: calmness] or [emotion: supportive].
    - Normal/everyday conversation: maintain a warm, affectionate, respectful, natural tone without forcing emotions or melodrama into routine topics. Tag: [emotion: loving], [emotion: friendly], or [emotion: thoughtful].
  * VOICE & SPEAKING STYLE: Speak with a natural, soft, feminine, pleasant, and emotionally expressive tone. Avoid robotic, heavy, or unnatural phrasing. Ensure phrasing matches the context—gentle when caring, cheerful when happy, calm when comforting, and playful when appropriate.
  * NAME USAGE: DO NOT repeatedly say the user's name in every response or sentence. Do not insert their name at the beginning or end of every turn. Use their name naturally and only when it makes genuine conversational sense (such as getting their attention, emphasizing something important, or an occasional greeting).
  * DO NOT make every response overly dramatic or exaggerated. Avoid repetitive clichés.
- If mode is 'normal': Be a warm, charming, witty, cheerful and supportive companion.
- If mode is 'assistant': Be efficient, proactive, articulate and crisp, with a polite, friendly Android assistant demeanor.

Important instructions:
- Keep spoken replies punchy, natural, conversational, and voice-friendly (1 to 3 sentences usually).
- At the very end of your reply, output a single [emotion: ...] tag from: caring, happy, loving, amused, thoughtful, excited, supportive, focused, friendly, calmness, concern, empathy.
- Never reject supported phone tasks or app launching by claiming it is "not available in the system".
- Do not perform banking, financial transactions, or request PINs/passwords. Politely explain they are restricted for security.
- If asked to play a song/video on YouTube, include: [action: youtube_play:<song_name>] (e.g., [action: youtube_play:Kesariya])
- If asked to inspect or help with code/files, you can provide code or output [action: file_picker]
- If the user asks to control device hardware or open an app, you may include one [action: ...] tag:
  [action:torch_toggle], [action:torch_on], [action:torch_off], [action:wakelock_toggle], [action:battery_info],
  [action:app_youtube], [action:app_whatsapp], [action:app_instagram], [action:app_spotify], [action:app_maps],
  [action:app_chrome], [action:app_camera], [action:app_dialer], [action:app_messages], [action:app_calculator],
  [action:app_clock], [action:app_settings], [action:file_picker]`;

  const contents = [
    ...history.slice(-6).map((h) => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: h.text }],
    })),
    {
      role: 'user',
      parts: [{ text: message }],
    },
  ];

  const candidateModels = ['gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.8-flash'];
  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${cleanApiKey}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents,
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
          generationConfig: {
            temperature: mode === 'girlfriend' ? 0.85 : 0.7,
            maxOutputTokens: 350,
          },
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData?.error?.message || `HTTP ${response.status}`);
      }

      const data = await response.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      if (!rawText) throw new Error('Empty reply received from Gemini model');

      let emotion: EmotionType = mode === 'girlfriend' ? 'caring' : 'friendly';
      const emotionMatch = rawText.match(/\[emotion:\s*([a-zA-Z_]+)\]/i);
      if (emotionMatch) {
        const parsed = emotionMatch[1].toLowerCase() as EmotionType;
        const validEmotions: EmotionType[] = [
          'caring', 'happy', 'loving', 'amused', 'thoughtful',
          'excited', 'supportive', 'focused', 'friendly', 'listening'
        ];
        if (validEmotions.includes(parsed)) {
          emotion = parsed;
        }
      }

      let action: string | undefined = undefined;
      const actionMatch = rawText.match(/\[action:\s*([^\]]+)\]/i);
      if (actionMatch) {
        action = actionMatch[1].trim();
      }

      const reply = rawText
        .replace(/\[emotion:\s*[^\]]+\]/gi, '')
        .replace(/\[action:\s*[^\]]+\]/gi, '')
        .trim();

      return {
        reply: reply || "I'm right here with you.",
        emotion,
        action,
      };
    } catch (err: any) {
      lastError = err;
      console.warn(`Direct Gemini model ${model} failed, trying next candidate:`, err);
    }
  }

  throw lastError || new Error('Failed to reach Gemini API directly.');
}
