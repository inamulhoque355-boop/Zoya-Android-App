import { EmotionType, VoiceSettings, LanguageCode } from '../types';
import { detectLanguageFromText, getLanguageBCP47 } from './languages';

// Speech Synthesis Helper
class SpeechController {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private onVoicesLoadedCallbacks: Array<(voices: SpeechSynthesisVoice[]) => void> = [];
  private onSpeakingChangeCallbacks: Array<(isSpeaking: boolean) => void> = [];
  private onBoundaryCallbacks: Array<(charIndex: number, name: string) => void> = [];
  private isPrewarmed = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  public onSpeakingChange(cb: (isSpeaking: boolean) => void): () => void {
    this.onSpeakingChangeCallbacks.push(cb);
    return () => {
      this.onSpeakingChangeCallbacks = this.onSpeakingChangeCallbacks.filter((c) => c !== cb);
    };
  }

  public onBoundary(cb: (charIndex: number, name: string) => void): () => void {
    this.onBoundaryCallbacks.push(cb);
    return () => {
      this.onBoundaryCallbacks = this.onBoundaryCallbacks.filter((c) => c !== cb);
    };
  }

  private notifySpeaking(speaking: boolean) {
    for (const cb of this.onSpeakingChangeCallbacks) {
      try {
        cb(speaking);
      } catch (err) {
        console.warn('Speaking callback error:', err);
      }
    }
  }

  private notifyBoundary(charIndex: number, name: string) {
    for (const cb of this.onBoundaryCallbacks) {
      try {
        cb(charIndex, name);
      } catch (err) {
        console.warn('Boundary callback error:', err);
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    const available = this.synth.getVoices();
    if (available && available.length > 0) {
      this.voices = available;
      this.onVoicesLoadedCallbacks.forEach((cb) => cb(this.voices));
    }
  }

  /**
   * Pre-warm speech synthesis engine on first click / touch.
   * Eliminates the ~500ms audio engine startup delay on mobile Android Chrome.
   */
  public prewarm() {
    if (this.isPrewarmed || !this.synth) return;
    try {
      const silent = new SpeechSynthesisUtterance('');
      silent.volume = 0;
      this.synth.speak(silent);
      this.isPrewarmed = true;
    } catch {
      // ignore
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.synth && this.voices.length === 0) {
      this.loadVoices();
    }
    return this.voices;
  }

  public onVoicesAvailable(cb: (voices: SpeechSynthesisVoice[]) => void) {
    if (this.voices.length > 0) {
      cb(this.voices);
    } else {
      this.onVoicesLoadedCallbacks.push(cb);
    }
  }

  public stop() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {
        // ignore
      }
      this.currentUtterance = null;
      this.notifySpeaking(false);
    }
  }

  public isSpeaking(): boolean {
    return Boolean(this.synth && this.synth.speaking);
  }

  public speak(
    text: string,
    settings: VoiceSettings,
    emotion?: EmotionType,
    onEnd?: () => void,
    onError?: (err: any) => void,
    languageOverride?: LanguageCode
  ) {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    this.stop();

    // Clean text of emojis, markdown or brackets for fast, pristine pronunciation
    const speechText = text
      .replace(/[*_#`~[\]]/g, '')
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!speechText) {
      if (onEnd) onEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(speechText);
    this.currentUtterance = utterance;

    // Detect language
    const langCode = (languageOverride && languageOverride !== 'auto')
      ? languageOverride
      : (settings.language && settings.language !== 'auto')
      ? settings.language
      : detectLanguageFromText(speechText);

    const bcp47 = getLanguageBCP47(langCode, speechText);
    utterance.lang = bcp47;

    // Base pitch & rate for a natural, soft, feminine, conversational tone
    // Default pitch ~1.14 provides a light, clear feminine timbre without sounding synthetic.
    // Default rate ~0.98 provides an unhurried, natural human cadence.
    let basePitch = settings.pitch || 1.14;
    let baseRate = settings.rate || 0.98;

    let targetPitch = basePitch;
    let targetRate = baseRate;

    if (emotion === 'loving') {
      // Soft, affectionate, intimate, slightly slower, gentle cadence
      targetPitch = Math.min(1.28, basePitch * 1.03);
      targetRate = Math.max(0.88, baseRate * 0.94);
    } else if (emotion === 'caring' || emotion === 'empathy') {
      // Tender, nurturing, soothing, warm and comforting
      targetPitch = Math.min(1.26, basePitch * 1.02);
      targetRate = Math.max(0.88, baseRate * 0.93);
    } else if (emotion === 'supportive') {
      // Reassuring, steady, patient, grounding warmth
      targetPitch = Math.min(1.24, basePitch * 1.01);
      targetRate = Math.max(0.90, baseRate * 0.95);
    } else if (emotion === 'amused') {
      // Playful, cheerful lilt, buoyant and smiling
      targetPitch = Math.min(1.30, basePitch * 1.05);
      targetRate = Math.min(1.15, baseRate * 1.03);
    } else if (emotion === 'happy') {
      // Bright, cheerful, joyful warmth
      targetPitch = Math.min(1.32, basePitch * 1.06);
      targetRate = Math.min(1.16, baseRate * 1.04);
    } else if (emotion === 'excited' || emotion === 'surprise') {
      // Sparkling, enthusiastic, animated and joyful
      targetPitch = Math.min(1.35, basePitch * 1.08);
      targetRate = Math.min(1.20, baseRate * 1.06);
    } else if (emotion === 'calmness') {
      // Soothing, steady, tranquil, de-escalating pace
      targetPitch = Math.max(1.02, basePitch * 0.98);
      targetRate = Math.max(0.88, baseRate * 0.92);
    } else if (emotion === 'sad' || emotion === 'concern') {
      // Soft, compassionate, slightly slower and gentle
      targetPitch = Math.max(1.04, basePitch * 0.97);
      targetRate = Math.max(0.88, baseRate * 0.92);
    } else if (emotion === 'thoughtful') {
      // Measured, sincere, reflective
      targetPitch = basePitch;
      targetRate = Math.max(0.90, baseRate * 0.95);
    } else if (emotion === 'shyness') {
      // Soft, delicate, gentle rise
      targetPitch = Math.min(1.28, basePitch * 1.04);
      targetRate = Math.max(0.88, baseRate * 0.94);
    } else if (emotion === 'focused') {
      targetPitch = Math.min(1.22, basePitch * 1.01);
      targetRate = Math.min(1.18, baseRate * 1.05);
    }

    utterance.pitch = Math.round(targetPitch * 100) / 100;
    utterance.rate = Math.round(targetRate * 100) / 100;

    // Native Android Bridge Check
    const android = typeof window !== 'undefined' ? (window as any).Android : null;
    if (android && typeof android.speak === 'function') {
      try {
        this.notifySpeaking(true);
        (window as any).onAndroidSpeechTtsStart = () => {
          this.notifySpeaking(true);
        };
        (window as any).onAndroidSpeechTtsEnd = () => {
          this.notifySpeaking(false);
          if (onEnd) onEnd();
        };

        android.speak(speechText, targetPitch, targetRate);
        return;
      } catch (err) {
        console.warn('Native Android TTS error, falling back to WebSpeech:', err);
      }
    }

    // Select voice according to language with prioritized natural, soft, feminine voices
    const available = this.getVoices();
    let selectedVoice: SpeechSynthesisVoice | undefined;

    if (settings.voiceURI) {
      selectedVoice = available.find((v) => v.voiceURI === settings.voiceURI);
    }

    if (!selectedVoice) {
      // Helper filter to score and find natural, feminine, high-clarity voices
      const findBestFeminineVoice = (langPrefix: string, preferredNames: string[]) => {
        const langVoices = available.filter((v) => v.lang.toLowerCase().startsWith(langPrefix.toLowerCase()));
        if (langVoices.length === 0) return undefined;

        // 1. Check for specific natural/neural preferred feminine voice names
        for (const pref of preferredNames) {
          const match = langVoices.find((v) => v.name.toLowerCase().includes(pref.toLowerCase()));
          if (match) return match;
        }

        // 2. Check for explicit "female" or "natural" / "online" in name
        const explicitFemale = langVoices.find(
          (v) =>
            v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('natural') ||
            v.name.toLowerCase().includes('neural') ||
            v.name.toLowerCase().includes('online')
        );
        if (explicitFemale) return explicitFemale;

        // 3. Avoid male or deep voice names (David, George, Mark, Male, Guy, etc.)
        const nonMale = langVoices.find(
          (v) =>
            !v.name.toLowerCase().includes('male') &&
            !v.name.toLowerCase().includes('david') &&
            !v.name.toLowerCase().includes('george') &&
            !v.name.toLowerCase().includes('mark') &&
            !v.name.toLowerCase().includes('guy') &&
            !v.name.toLowerCase().includes('richard') &&
            !v.name.toLowerCase().includes('james')
        );
        if (nonMale) return nonMale;

        return langVoices[0];
      };

      if (langCode === 'as') {
        // Look for Assamese voice (as-IN or name containing Assamese)
        selectedVoice = available.find(
          (v) =>
            v.lang.toLowerCase().includes('as-in') ||
            v.lang.toLowerCase().startsWith('as') ||
            v.name.toLowerCase().includes('assamese')
        );
        // Fallback for Assamese to high-quality Eastern Indic / Bengali / Hindi natural feminine voice
        if (!selectedVoice) {
          selectedVoice =
            findBestFeminineVoice('bn', ['tanisha', 'bashkar', 'google', 'female', 'natural']) ||
            findBestFeminineVoice('hi', ['swara', 'madhur', 'kalpana', 'google', 'female', 'natural']);
        }
      } else if (langCode === 'hi') {
        selectedVoice = findBestFeminineVoice('hi', [
          'swara',
          'google हिन्दी',
          'google hindi',
          'madhur',
          'kalpana',
          'ananya',
          'female',
          'natural',
        ]);
      } else if (langCode === 'bn') {
        selectedVoice = findBestFeminineVoice('bn', ['tanisha', 'google', 'female', 'natural']);
      } else if (langCode === 'ur') {
        selectedVoice = findBestFeminineVoice('ur', ['google', 'female', 'natural']);
      }

      // Default English voice selection: prioritize natural, warm, feminine voices
      if (!selectedVoice) {
        selectedVoice = findBestFeminineVoice('en', [
          // Natural / Neural voices
          'natural',
          'samantha',
          'zira',
          'karen',
          'victoria',
          'serena',
          'fiona',
          'ava',
          'jenny',
          'aria',
          'emma',
          'google us english',
          'google uk english female',
          'female',
        ]);
      }
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onstart = () => {
      this.notifySpeaking(true);
    };

    utterance.onboundary = (event: any) => {
      this.notifyBoundary(event.charIndex || 0, event.name || 'word');
    };

    utterance.onend = () => {
      this.currentUtterance = null;
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      this.currentUtterance = null;
      this.notifySpeaking(false);
      if (onError) onError(e);
      else if (onEnd) onEnd();
    };

    try {
      this.synth.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis speak error:', e);
      this.notifySpeaking(false);
      if (onEnd) onEnd();
    }
  }
}

export const speechController = new SpeechController();

// Speech Recognition (Microphone) Options
export interface SpeechRecognizerOptions {
  onResult: (transcript: string, isFinal: boolean) => void;
  onStart: () => void;
  onEnd: () => void;
  onError: (error: string) => void;
  // Fast silence threshold in ms (defaults to 750ms for lightning speed)
  silenceTimeoutMs?: number;
  language?: LanguageCode;
}

/**
 * Creates high-performance SpeechRecognizer with early intent triggers
 * and low-latency silence auto-finalization.
 */
export function createSpeechRecognizer(callbacks: SpeechRecognizerOptions) {
  if (typeof window === 'undefined') return null;

  // 1. Native Android SpeechRecognizer Bridge
  const android = (window as any).Android;
  if (android && typeof android.startListening === 'function') {
    (window as any).onAndroidSpeechReady = () => {
      callbacks.onStart();
    };
    (window as any).onAndroidSpeechResult = (text: string, isFinal: boolean) => {
      callbacks.onResult(text, isFinal);
    };
    (window as any).onAndroidSpeechEnd = () => {
      callbacks.onEnd();
    };
    (window as any).onAndroidSpeechError = (error: string) => {
      callbacks.onError(error);
    };

    return {
      start: () => {
        try {
          android.startListening();
        } catch (e: any) {
          callbacks.onError(e?.message || 'Native listening failed');
        }
      },
      stop: () => {
        try {
          android.stopListening();
        } catch {
          // ignore
        }
      },
      abort: () => {
        try {
          android.stopListening();
        } catch {
          // ignore
        }
      },
    };
  }

  // 2. Browser WebSpeech API Fallback
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  try {
    const recognizer = new SpeechRecognition();
    recognizer.continuous = false;
    recognizer.interimResults = true;
    const targetLang = getLanguageBCP47(callbacks.language || 'auto');
    recognizer.lang = targetLang;
    recognizer.maxAlternatives = 1;

    let silenceTimer: any = null;
    let latestTranscript = '';
    let hasTriggeredFinal = false;

    const clearSilenceTimer = () => {
      if (silenceTimer) {
        clearTimeout(silenceTimer);
        silenceTimer = null;
      }
    };

    recognizer.onstart = () => {
      hasTriggeredFinal = false;
      latestTranscript = '';
      callbacks.onStart();
    };

    recognizer.onresult = (event: any) => {
      clearSilenceTimer();
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      if (finalTranscript) {
        hasTriggeredFinal = true;
        clearSilenceTimer();
        callbacks.onResult(finalTranscript.trim(), true);
        try {
          recognizer.stop();
        } catch {
          // ignore
        }
      } else if (interimTranscript) {
        latestTranscript = interimTranscript.trim();
        callbacks.onResult(latestTranscript, false);

        // Fast Silence Finalizer:
        // WebSpeech often lingers for 1.5s after user stops talking.
        // We set a brief silence timer (e.g. 700ms) to auto-finalize and respond with minimum delay.
        const timeout = callbacks.silenceTimeoutMs || 700;
        silenceTimer = setTimeout(() => {
          if (!hasTriggeredFinal && latestTranscript.length > 0) {
            hasTriggeredFinal = true;
            callbacks.onResult(latestTranscript, true);
            try {
              recognizer.stop();
            } catch {
              // ignore
            }
          }
        }, timeout);
      }
    };

    recognizer.onerror = (event: any) => {
      clearSilenceTimer();
      console.warn('Speech recognition error:', event.error);
      callbacks.onError(event.error);
    };

    recognizer.onend = () => {
      clearSilenceTimer();
      // If ended naturally and we have a transcript that was not finalized, finalize it now
      if (!hasTriggeredFinal && latestTranscript.length > 0) {
        hasTriggeredFinal = true;
        callbacks.onResult(latestTranscript, true);
      }
      callbacks.onEnd();
    };

    return recognizer;
  } catch (err: any) {
    console.warn('Failed to initialize SpeechRecognition:', err);
    return null;
  }
}
