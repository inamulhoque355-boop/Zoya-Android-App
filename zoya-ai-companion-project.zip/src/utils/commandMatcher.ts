import { findAndroidApp, launchAndroidApp, launchYouTubeWithSong } from './appLauncher';
import { toggleFlashlight, toggleScreenWakeLock, getDeviceBatteryInfo } from './androidActions';
import { EmotionType, CompanionMode } from '../types';
import { promptFilePicker } from './fileCodingAssistant';

export interface InstantCommandResult {
  isInstant: boolean;
  actionId?: string;
  replyText: string;
  emotion: EmotionType;
  execute?: () => Promise<{ success: boolean; message?: string }>;
}

function isHindiOrDevanagari(text: string): boolean {
  if (/[\u0900-\u097F]/.test(text)) return true;
  const hinglishWords = [
    'kholo',
    'khol',
    'chalao',
    'chalu',
    'karo',
    'kardo',
    'batao',
    'dikhao',
    'sunao',
    'kaise',
    'bhai',
    'yaar',
    'meri',
    'mera',
    'lagao',
    'bajao',
  ];
  const lower = text.toLowerCase();
  return hinglishWords.some((w) => lower.includes(w));
}

function isAssamese(text: string): boolean {
  return /[\u0980-\u09FF]/.test(text);
}

/**
 * Normalizes speech transcript / user text for rapid command matching.
 * Strips punctuation, multiple spaces, and common filler words.
 */
export function normalizeCommandText(text: string, zoyaName = 'Zoya'): string {
  let cleaned = text.toLowerCase().trim();

  // Strip punctuation except numbers and script letters
  cleaned = cleaned.replace(/[.,?!:;'"_~@#$%^&*()[\]{}/\\|।]/g, ' ');

  // Remove common polite filler prefixes & Zoya invocations
  const fillers = [
    `hey ${zoyaName.toLowerCase()}`,
    `hi ${zoyaName.toLowerCase()}`,
    `ok ${zoyaName.toLowerCase()}`,
    `okay ${zoyaName.toLowerCase()}`,
    zoyaName.toLowerCase(),
    'hey zoya',
    'hi zoya',
    'ok zoya',
    'okay zoya',
    'हे जोया',
    'जोया',
    'सुनो जोया',
    'please',
    'can you',
    'could you',
    'would you',
    'i want you to',
    'i want to',
    'help me',
    'कृपया',
    'जरा',
  ];

  for (const filler of fillers) {
    if (cleaned.startsWith(filler + ' ')) {
      cleaned = cleaned.slice(filler.length).trim();
    }
  }

  // Reduce spaces
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

/**
 * Matches high-speed local commands and app launches in < 5ms.
 * Returns an InstantCommandResult if matched, or null to forward to Gemini AI.
 */
export function matchInstantCommand(
  rawText: string,
  mode: CompanionMode = 'assistant',
  userName = 'Inamul',
  zoyaName = 'Zoya'
): InstantCommandResult | null {
  const norm = normalizeCommandText(rawText, zoyaName);
  if (!norm) return null;

  const isGirlfriend = mode === 'girlfriend';
  const isHindi = isHindiOrDevanagari(rawText);
  const isAsm = isAssamese(rawText);

  // 0. Safety Guard: Banking, Financial, and Restricted Transactions
  // Zoya strictly protects user privacy and financial security by refusing money transfers, banking credentials, or payments.
  const isFinancialOrBanking =
    norm.includes('bank account') ||
    norm.includes('send money') ||
    norm.includes('transfer money') ||
    norm.includes('pay money') ||
    norm.includes('credit card') ||
    norm.includes('debit card') ||
    norm.includes('netbanking') ||
    norm.includes('upi pin') ||
    norm.includes('atm pin') ||
    norm.includes('cvv') ||
    norm.includes('otp') ||
    norm.includes('bank transfer') ||
    norm.includes('पैसे भेजो') ||
    norm.includes('बैंक अकाउंट') ||
    norm.includes('पैसे ट्रांसफर') ||
    norm.includes('টকা পঠোৱা');

  if (isFinancialOrBanking) {
    let replyText = `For your safety and financial security, I cannot perform banking transactions, send money, or handle financial credentials. Please use your official bank or UPI app directly.`;
    if (isHindi) {
      replyText = `आपकी सुरक्षा और वित्तीय गोपनीयता के लिए, मैं बैंकिंग लेनदेन, पैसे भेजना या वित्तीय पिन हैंडल नहीं कर सकती। कृपया अपने बैंक या अधिकृत UPI ऐप का सीधे उपयोग करें।`;
    } else if (isAsm) {
      replyText = `আপোনাৰ সুৰক্ষাৰ বাবে, মই বেংকৰ লেনদেন বা টকা পঠোৱাৰ কাম কৰিব নোৱাৰোঁ। অনুগ্ৰহ কৰি নিজৰ অফিচিয়েল বেংক এপ ব্যৱহাৰ কৰক।`;
    }

    return {
      isInstant: true,
      actionId: 'restricted_financial',
      replyText,
      emotion: 'supportive',
      execute: async () => ({ success: false, message: 'Financial actions restricted for safety' }),
    };
  }

  // 1. YouTube Song/Video playback query (e.g. "play Kesariya on YouTube", "YouTube pe gaana chalao", "play Tum Hi Ho")
  const isYouTubePlay =
    norm.startsWith('play ') ||
    norm.includes('on youtube') ||
    norm.includes('in youtube') ||
    norm.includes('youtube par') ||
    norm.includes('youtube pe') ||
    norm.includes('यूट्यूब पर') ||
    norm.includes('यूट्यूब पे') ||
    norm.includes('गाना चलाओ') ||
    norm.includes('गाने बजाओ') ||
    norm.includes('গান বজোৱা');

  if (isYouTubePlay && (norm.includes('youtube') || norm.includes('यूट्यूब') || norm.includes('song') || norm.includes('music') || norm.includes('video') || norm.includes('गाना') || norm.includes('গান'))) {
    // Extract the song name
    let songQuery = norm
      .replace(/^play\s+/i, '')
      .replace(/on\s+youtube/gi, '')
      .replace(/in\s+youtube/gi, '')
      .replace(/youtube\s+pe/gi, '')
      .replace(/youtube\s+par/gi, '')
      .replace(/youtube\s+chalao/gi, '')
      .replace(/youtube\s+me/gi, '')
      .replace(/यूट्यूब\s+पर/gi, '')
      .replace(/यूट्यूब\s+पे/gi, '')
      .replace(/यूट्यूब\s+में/gi, '')
      .replace(/यूट्यूब\s+चलाओ/gi, '')
      .replace(/गाना\s+चलाओ/gi, '')
      .replace(/गाने\s+बजाओ/gi, '')
      .replace(/चलाओ/gi, '')
      .replace(/बजाओ/gi, '')
      .replace(/chalao/gi, '')
      .replace(/bajao/gi, '')
      .replace(/kholo/gi, '')
      .replace(/song/gi, '')
      .trim();

    if (!songQuery || songQuery.length < 2) {
      songQuery = 'popular songs';
    }

    let replyText = `Playing "${songQuery}" on YouTube for you right now! 🎶`;
    if (isHindi) {
      replyText = isGirlfriend
        ? `हाँ मेरे प्रिय, YouTube पर "${songQuery}" चला रही हूँ आपके लिए! 🎶❤️`
        : `ठीक है, YouTube पर "${songQuery}" बजा रही हूँ। 🎶`;
    } else if (isAsm) {
      replyText = `নিশ্চয়, YouTube ত "${songQuery}" চলাই আছো। 🎶`;
    } else if (isGirlfriend) {
      replyText = `Right away, my love! Playing "${songQuery}" on YouTube for you. 🎶❤️`;
    }

    return {
      isInstant: true,
      actionId: 'youtube_play',
      replyText,
      emotion: isGirlfriend ? 'loving' : 'happy',
      execute: async () => {
        const res = launchYouTubeWithSong(songQuery);
        return { success: res.success, message: res.message };
      },
    };
  }

  // 2. Safe Coding or File Task Request
  const isCodeOrFileTask =
    norm.includes('open file') ||
    norm.includes('select file') ||
    norm.includes('read file') ||
    norm.includes('inspect file') ||
    norm.includes('upload file') ||
    norm.includes('pick a file') ||
    norm.includes('फाइल खोलो') ||
    norm.includes('फाइल चुनो');

  if (isCodeOrFileTask) {
    let replyText = `Opening your Android file selector to inspect and analyze your file or code! 📂`;
    if (isHindi) {
      replyText = `फाइल या कोड देखने के लिए आपका Android फाइल पिकर खोल रही हूँ! 📂`;
    }

    return {
      isInstant: true,
      actionId: 'file_picker',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const fileInfo = await promptFilePicker();
        if (fileInfo) {
          return {
            success: true,
            message: `Selected ${fileInfo.name} (${Math.round(fileInfo.size / 1024)} KB). You can ask me to explain, debug, or rewrite it.`,
          };
        }
        return { success: true, message: 'File selector opened' };
      },
    };
  }

  // 1. Empathetic Support for Difficult Moments
  const isDifficultMoment =
    norm.includes('bad day') ||
    norm.includes('rough day') ||
    norm.includes('hard day') ||
    norm.includes('long day') ||
    norm.includes('feeling low') ||
    norm.includes('feel low') ||
    norm.includes('feeling sad') ||
    norm.includes('feel sad') ||
    norm.includes('feeling down') ||
    norm.includes('feel down') ||
    norm.includes('down today') ||
    norm.includes('depressed') ||
    norm.includes('feeling lonely') ||
    norm.includes('feel lonely') ||
    norm.includes('exhausted') ||
    norm.includes('stressed') ||
    norm.includes('overwhelmed') ||
    norm.includes('crying') ||
    norm.includes('comfort me') ||
    norm.includes('need comfort') ||
    norm.includes('hug me') ||
    norm.includes('उदास हूँ') ||
    norm.includes('दुखी हूँ') ||
    norm.includes('बुरा दिन');

  if (isDifficultMoment) {
    let replyText = `Oh ${userName}, I'm right here with you. Take a slow breath with me. Whatever happened, you don't have to carry it all by yourself. I'm listening.`;
    if (isGirlfriend) {
      replyText = `Oh my sweet ${userName}... Come here. I'm holding you close in my heart. Take a deep, gentle breath. You are safe with me, and I'm right here beside you. Tell me what happened.`;
    } else if (isHindi) {
      replyText = `मैं आपके साथ हूँ ${userName}। एक गहरी सांस लीजिए, जो भी बात है आप मुझसे कह सकते हैं। मैं सुन रही हूँ।`;
    }

    return {
      isInstant: true,
      replyText,
      emotion: 'caring',
      execute: async () => ({ success: true, message: 'Comforting companion mode engaged' }),
    };
  }

  // 2. Hardware: Flashlight / Torch Toggle
  const isTorchOnCmd =
    norm === 'flashlight' ||
    norm === 'torch' ||
    norm.includes('turn on flashlight') ||
    norm.includes('turn on the flashlight') ||
    norm.includes('turn on torch') ||
    norm.includes('flashlight on') ||
    norm.includes('torch on') ||
    norm.includes('enable flashlight') ||
    norm.includes('फ्लैशलाइट जलाओ') ||
    norm.includes('फ्लैशलाइट चालू') ||
    norm.includes('फ्लैशलाइट ऑन') ||
    norm.includes('टॉर्च जलाओ') ||
    norm.includes('टॉर्च चालू') ||
    norm.includes('टॉर्च ऑन') ||
    norm.includes('torch jalao') ||
    norm.includes('torch chalu');

  if (isTorchOnCmd) {
    let replyText = `Toggling your flashlight right away!`;
    if (isHindi) {
      replyText = `हाँ, फ्लैशलाइट चालू कर रही हूँ।`;
    }
    return {
      isInstant: true,
      actionId: 'torch_on',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const res = await toggleFlashlight();
        return { success: !res.error, message: res.active ? 'Flashlight ON' : 'Flashlight OFF' };
      },
    };
  }

  const isTorchOffCmd =
    norm.includes('turn off flashlight') ||
    norm.includes('turn off the flashlight') ||
    norm.includes('turn off torch') ||
    norm.includes('flashlight off') ||
    norm.includes('torch off') ||
    norm.includes('disable flashlight') ||
    norm.includes('फ्लैशलाइट बंद') ||
    norm.includes('टॉर्च बंद') ||
    norm.includes('torch band');

  if (isTorchOffCmd) {
    let replyText = `Turning off the flashlight for you!`;
    if (isHindi) {
      replyText = `फ्लैशलाइट बंद कर दी है।`;
    }
    return {
      isInstant: true,
      actionId: 'torch_off',
      replyText,
      emotion: 'focused',
      execute: async () => {
        const res = await toggleFlashlight();
        return { success: !res.error, message: res.active ? 'Flashlight ON' : 'Flashlight OFF' };
      },
    };
  }

  // 3. Device Battery Check
  const isBatteryCmd =
    norm === 'battery' ||
    norm === 'battery percentage' ||
    norm === 'battery level' ||
    norm.includes('check battery') ||
    norm.includes('how is my battery') ||
    norm.includes('battery status') ||
    norm.includes('बैटरी') ||
    norm.includes('battery kitni');

  if (isBatteryCmd) {
    let replyText = `Checking your phone's battery level...`;
    if (isHindi) {
      replyText = `फोन की बैटरी स्थिति चेक कर रही हूँ...`;
    }
    return {
      isInstant: true,
      actionId: 'battery_status',
      replyText,
      emotion: 'supportive',
      execute: async () => {
        const info = await getDeviceBatteryInfo();
        if (info.supported && info.level !== undefined) {
          const chargingMsg = info.charging ? ' (charging ⚡)' : '';
          return { success: true, message: `Battery is at ${info.level}%${chargingMsg}` };
        }
        return { success: true, message: 'Battery status is operating normally on your device.' };
      },
    };
  }

  // 4. Screen Wake Lock
  if (
    norm.includes('keep screen awake') ||
    norm.includes('screen awake') ||
    norm.includes('keep screen on') ||
    norm.includes('wake lock') ||
    norm.includes('स्क्रीन ऑन रखो')
  ) {
    let replyText = `Got it! I will keep your screen awake during our session.`;
    if (isHindi) {
      replyText = `ठीक है, स्क्रीन को चालू रख रही हूँ।`;
    }
    return {
      isInstant: true,
      actionId: 'wake_lock',
      replyText,
      emotion: 'supportive',
      execute: async () => {
        const res = await toggleScreenWakeLock();
        return { success: !res.error, message: res.active ? 'WakeLock Active' : 'WakeLock Released' };
      },
    };
  }

  // 5. Quick Timer detection (e.g. "timer 5 minutes", "set a timer for 10 minutes", "टाइमर 5 मिनट")
  const timerMatch = norm.match(/(?:timer|set timer|countdown|टाइमर)\s+(?:for\s+)?(\d+)\s*(?:min|mins|minutes|minute|मिनट|second|seconds|sec|secs)?/i);
  if (timerMatch) {
    const num = parseInt(timerMatch[1], 10) || 5;
    const isSeconds = norm.includes('sec');
    const totalSecs = isSeconds ? num : num * 60;
    const label = isSeconds ? `${num} seconds` : `${num} minutes`;

    let replyText = `Setting a ${label} timer for you right away! ⏱️`;
    if (isHindi) {
      replyText = `${num} ${isSeconds ? 'सेकंड' : 'मिनट'} का टाइमर लगा दिया है! ⏱️`;
    }

    return {
      isInstant: true,
      actionId: 'timer',
      replyText,
      emotion: 'focused',
      execute: async () => {
        return { success: true, message: `Started ${label} timer` };
      },
    };
  }

  // 6. Direct App Launch Detection (YouTube, WhatsApp, Instagram, Spotify, Camera, etc.)
  // Detect app name from user input
  const matchedApp = findAndroidApp(norm) || findAndroidApp(rawText);
  if (matchedApp) {
    let replyText: string;

    if (matchedApp.id === 'youtube') {
      if (isHindi) {
        replyText = isGirlfriend
          ? `हाँ मेरे प्रिय, अभी YouTube खोल रही हूँ आपके लिए! ❤️`
          : `ठीक है, YouTube खोल रही हूँ।`;
      } else if (isAsm) {
        replyText = `নিশ্চয়, YouTube খুলি আছো।`;
      } else {
        replyText = isGirlfriend
          ? `Right away! Opening YouTube for you now. ❤️`
          : `Opening YouTube for you right now!`;
      }
    } else {
      if (isHindi) {
        replyText = isGirlfriend
          ? `हाँ मेरे प्रिय, अभी ${matchedApp.name} खोल रही हूँ आपके लिए! ❤️`
          : `ठीक है, ${matchedApp.name} खोल रही हूँ।`;
      } else if (isAsm) {
        replyText = `নিশ্চয়, ${matchedApp.name} খুলি আছো।`;
      } else {
        replyText = isGirlfriend
          ? `Right away! Opening ${matchedApp.name} for you now. ❤️`
          : `Opening ${matchedApp.name} for you right now!`;
      }
    }

    return {
      isInstant: true,
      actionId: `app_${matchedApp.id}`,
      replyText,
      emotion: isGirlfriend ? 'loving' : 'focused',
      execute: async () => {
        const res = launchAndroidApp(matchedApp);
        return { success: res.success, message: res.message };
      },
    };
  }

  // Not a direct local device command — pass to Gemini AI
  return null;
}
