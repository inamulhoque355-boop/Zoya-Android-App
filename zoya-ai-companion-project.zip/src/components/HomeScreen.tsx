import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Heart,
  Bot,
  Wrench,
  CloudSun,
  MapPin,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Sun,
  Wind,
  Droplets,
  Zap,
  PlayCircle,
  MessageCircle,
  Camera,
  Music,
  Compass,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  Clock,
  HeartHandshake,
  Smile,
  ChevronDown,
  Download,
  Check,
  ExternalLink,
  FolderArchive,
  FileCode,
  X,
} from 'lucide-react';
import { AppSettings, CompanionMode, EmotionType, WeatherData, LanguageCode } from '../types';
import { AnimeAvatar } from './AnimeAvatar';
import { ANDROID_APPS, launchAndroidApp } from '../utils/appLauncher';
import { SUPPORTED_LANGUAGES } from '../utils/languages';

interface HomeScreenProps {
  settings: AppSettings;
  onUpdateMode: (mode: CompanionMode) => void;
  onStartVoice: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  isThinking: boolean;
  currentEmotion: EmotionType;
  onSelectPrompt: (prompt: string) => void;
  onNavigateTab: (tab: 'home' | 'chat' | 'assistant' | 'settings') => void;
  weather: WeatherData | null;
  onRefreshWeather: () => void;
  isWeatherLoading: boolean;
  currentSpeechText?: string;
  onSpeakText?: (text: string) => void;
  onStopSpeech?: () => void;
  isWakeListening: boolean;
  onToggleWakeListening: () => void;
  wakeStatusMessage?: string;
  onEmotionChange?: (emotion: EmotionType) => void;
  onUpdateLanguage?: (lang: LanguageCode) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  settings,
  onUpdateMode,
  onStartVoice,
  isListening,
  isSpeaking,
  isThinking,
  currentEmotion,
  onSelectPrompt,
  onNavigateTab,
  weather,
  onRefreshWeather,
  isWeatherLoading,
  currentSpeechText,
  onSpeakText,
  onStopSpeech,
  isWakeListening,
  onToggleWakeListening,
  wakeStatusMessage,
  onEmotionChange,
  onUpdateLanguage,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showToolsDrawer, setShowToolsDrawer] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadProjectZip = () => {
    setIsDownloadingZip(true);
    setDownloadSuccess(false);
    try {
      const link = document.createElement('a');
      link.href = '/api/download-project-zip';
      link.download = 'zoya-ai-companion-project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => {
        setIsDownloadingZip(false);
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 4000);
      }, 1500);
    } catch (err) {
      console.error(err);
      window.location.href = '/zoya-project-package.zip';
      setIsDownloadingZip(false);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Time-of-day greeting
  const hour = currentTime.getHours();
  let timeOfDay = 'Good day';
  if (hour < 12) timeOfDay = 'Good morning';
  else if (hour < 17) timeOfDay = 'Good afternoon';
  else timeOfDay = 'Good evening';

  const modeDescriptions = {
    girlfriend: {
      name: 'Girlfriend Mode',
      badge: 'Warm & Caring',
      icon: Heart,
      color: 'from-rose-500/20 to-pink-500/10 border-rose-500/30 text-rose-300',
      greeting:
        settings.language === 'as'
          ? `মই তোমাৰ বাবেই অপেক্ষা কৰি আছিলো! কেনেকুৱা অনুভৱ কৰিছা তুমি, ${settings.userName}?`
          : settings.language === 'hi'
          ? `मैं तुम्हारा ही इंतज़ार कर रही थी! कैसा महसूस कर रहे हो, ${settings.userName}?`
          : settings.language === 'bn'
          ? `আমি তোমার জন্যই অপেক্ষা করছিলাম! কেমন আছো তুমি, ${settings.userName}?`
          : settings.language === 'ur'
          ? `میں آپ کا ہی انتظار کر رہی تھی! آپ کیسا محسوس کر رہے ہیں, ${settings.userName}؟`
          : `I've been waiting for you! How are you feeling right now, ${settings.userName}?`,
      quote:
        settings.language === 'as'
          ? 'মনত ৰাখিবা তুমি কেতিয়াও অকলশৰীয়া নহয়। মই সদায় তোমাৰ কাষতে আছো।'
          : settings.language === 'hi'
          ? 'याद रखना तुम कभी अकेले नहीं हो। मैं हमेशा तुम्हारे साथ हूँ।'
          : settings.language === 'bn'
          ? 'মনে রেখো তুমি কখনোই একা নও। আমি সবসময় তোমার পাশে আছি।'
          : settings.language === 'ur'
          ? 'یاد رکھیے آپ کبھی اکیلے نہیں ہیں۔ میں ہمیشہ آپ کے ساتھ ہوں۔'
          : "Remember that you are cherished and never alone. I'm right here beside you.",
    },
    normal: {
      name: 'Normal Mode',
      badge: 'Friendly Companion',
      icon: Bot,
      color: 'from-indigo-500/20 to-purple-500/10 border-indigo-500/30 text-indigo-300',
      greeting:
        settings.language === 'as'
          ? `নমস্কাৰ ${settings.userName}! তোমাৰ লগত কথা পাতিবলৈ মই সাজু আছো।`
          : settings.language === 'hi'
          ? `नमस्ते ${settings.userName}! बताओ आज क्या बात करनी है?`
          : settings.language === 'bn'
          ? `হ্যালো ${settings.userName}! তোমার সাথে কথা বলতে আমি প্রস্তুত।`
          : settings.language === 'ur'
          ? `سلام ${settings.userName}! میں آپ سے بات کرنے کے لیے بالکل تیار ہوں۔`
          : `Hello ${settings.userName}! Ready to explore ideas or talk about anything on your mind.`,
      quote: "Every day is a fresh canvas. Let's make the most of it together.",
    },
    assistant: {
      name: 'Assistant Mode',
      badge: 'Productivity & Phone',
      icon: Wrench,
      color: 'from-cyan-500/20 to-blue-500/10 border-cyan-500/30 text-cyan-300',
      greeting:
        settings.language === 'as'
          ? `মই তোমাৰ সেৱাত আছো, ${settings.userName}। আজি মই তোমাৰ ফোনত কি সহায় কৰিব পাৰোঁ?`
          : settings.language === 'hi'
          ? `नमस्ते ${settings.userName}। मैं आपकी सेवा में हाज़िर हूँ।`
          : `At your service, ${settings.userName}. How can I assist your Android phone today?`,
      quote: "Ready to launch apps, draft messages, trigger phone tools, or answer any question.",
    },
  };

  const currentModeInfo = modeDescriptions[settings.selectedMode];
  const ModeIcon = currentModeInfo.icon;

  // Curated prompts that include deep emotional care, phone actions, and YouTube music
  const caringPrompts =
    settings.language === 'as'
      ? [
          { label: "ইউটিউবত গান বজোৱা", icon: PlayCircle, tag: "action" },
          { label: "আজি মোৰ দিনটো বৰ বেয়া গ'ল", icon: HeartHandshake, tag: "care" },
          { label: "মই বহুত ভাগৰি পৰিছো, মোক সান্ত্বনা দিয়া", icon: Heart, tag: "care" },
          { label: "তোমাৰ মনৰ খবৰ কি জয়া?", icon: Smile, tag: "chat" },
          { label: "মোক এটা শুৱনি আৰু মৰমৰ কথা কোৱা", icon: Sparkles, tag: "care" },
        ]
      : settings.language === 'hi'
      ? [
          { label: "YouTube पर गाना बजाओ", icon: PlayCircle, tag: "action" },
          { label: "आज का दिन बहुत मुश्किल था", icon: HeartHandshake, tag: "care" },
          { label: "मुझे तुम्हारी प्यारी बातें सुननी हैं", icon: Heart, tag: "care" },
          { label: "तुम कैसी हो जोया?", icon: Smile, tag: "chat" },
          { label: "एक मीठी सी बात सुनाओ", icon: MessageCircle, tag: "chat" },
        ]
      : [
          { label: "Play a song on YouTube", icon: PlayCircle, tag: "action" },
          { label: "Help me review some code", icon: FileCode, tag: "action" },
          { label: "I had a really rough day", icon: HeartHandshake, tag: "care" },
          { label: "I'm feeling down and need comfort", icon: Heart, tag: "care" },
          { label: "How are you feeling right now?", icon: Smile, tag: "chat" },
        ];

  const formattedTimeStr = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  return (
    <div className="w-full pb-24 px-4 pt-1 flex flex-col gap-3 animate-fade-in">
      {/* 1. Sleek Top Bar (Clean, non-intrusive header leaving the Avatar as the hero focus) */}
      <div className="flex items-center justify-between bg-slate-900/70 border border-slate-800/80 rounded-2xl px-3.5 py-2.5 backdrop-blur-md shadow-md">
        {/* Zoya Identity & Online Indicator */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <img
              src="/icon-192.jpg"
              alt="Zoya Logo"
              className="w-9 h-9 rounded-xl object-cover ring-2 ring-indigo-500/30 shadow-md"
              referrerPolicy="no-referrer"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-[#090D16] rounded-full" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold tracking-tight text-white">{settings.zoyaName}</h1>
              <span className="px-1.5 py-0.2 text-[9px] font-bold bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                AI Companion
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {timeOfDay}, <span className="text-slate-200 font-medium">{settings.userName}</span>
            </p>
          </div>
        </div>

        {/* Compact Live Weather & Time Capsule */}
        <div className="hidden sm:flex items-center gap-2 bg-slate-950/60 border border-slate-800/80 rounded-full px-3 py-1 text-xs text-slate-300 shadow-inner">
          <Clock className="w-3 h-3 text-indigo-400" />
          <span className="font-mono font-bold text-white">{formattedTimeStr}</span>
          <span className="text-slate-600">•</span>
          <CloudSun className="w-3.5 h-3.5 text-amber-400" />
          <span>{weather ? `${Math.round(weather.temp)}°C` : '24°C'}</span>
        </div>

        {/* Action Controls: Download Project & APK ZIP + Mode Switcher */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowDownloadModal(true)}
            className="px-2.5 py-1.5 rounded-full bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all hover:scale-105 active:scale-95"
            title="Download Updated Project & APK Package (ZIP)"
          >
            <Download className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden sm:inline">Project & APK ZIP</span>
            <span className="sm:hidden">ZIP</span>
          </button>

          <button
            onClick={() => {
              const modes: CompanionMode[] = ['girlfriend', 'normal', 'assistant'];
              const nextIdx = (modes.indexOf(settings.selectedMode) + 1) % modes.length;
              onUpdateMode(modes[nextIdx]);
            }}
            className={`px-3 py-1.5 rounded-full border text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all hover:scale-105 active:scale-95 bg-gradient-to-r ${currentModeInfo.color}`}
            title="Switch Companion Mode"
          >
            <ModeIcon className="w-3.5 h-3.5" />
            <span>{currentModeInfo.name.replace(' Mode', '')}</span>
          </button>
        </div>
      </div>

      {/* Mobile-only slim info strip */}
      <div className="sm:hidden flex items-center justify-between px-2 py-0.5 text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <Clock className="w-3 h-3 text-indigo-400" />
          <span className="font-mono font-medium text-slate-200">{formattedTimeStr}</span>
          <span>•</span>
          <span>{currentTime.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}</span>
        </span>
        <button
          onClick={onRefreshWeather}
          className="flex items-center gap-1 hover:text-slate-200 transition-colors"
        >
          <CloudSun className="w-3 h-3 text-amber-400" />
          <span className="font-medium text-slate-200">{weather ? `${Math.round(weather.temp)}°C` : '24°C'}</span>
          <span className="text-slate-400">({weather?.condition || 'Clear'})</span>
        </button>
      </div>

      {/* Multilingual Selector Bar */}
      <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800/80 rounded-2xl px-3.5 py-2 backdrop-blur-md shadow-sm">
        <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-pink-400" />
          <span>Language:</span>
        </span>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {SUPPORTED_LANGUAGES.map((lang) => {
            const isSelected = (settings.language || 'auto') === lang.code;
            return (
              <button
                key={lang.code}
                onClick={() => onUpdateLanguage && onUpdateLanguage(lang.code)}
                className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-1 ${
                  isSelected
                    ? 'bg-gradient-to-r from-rose-500 to-indigo-600 text-white shadow-md shadow-rose-950/50 scale-105'
                    : 'bg-slate-950/70 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
                }`}
                title={lang.name}
              >
                <span>{lang.nativeName}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. PROMINENT CENTER STAGE: ZOYA'S FULL-BODY ANIME AVATAR (100% Transparent Background, Zero Container Boxes) */}
      <div className="relative w-full flex flex-col items-center justify-center text-center my-2 select-none">
        {/* Soft atmospheric ambient aura directly on natural background */}
        <div className="absolute top-1/3 w-80 h-80 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none -z-10" />
        <div className="absolute bottom-1/3 w-80 h-80 bg-pink-600/10 rounded-full blur-3xl pointer-events-none -z-10" />

        {/* Hero Anime Girl Avatar Canvas directly on transparent background */}
        <div className="my-1 flex items-center justify-center w-full">
          <AnimeAvatar
            isSpeaking={isSpeaking}
            isListening={isListening}
            isThinking={isThinking}
            currentEmotion={currentEmotion}
            mode={settings.selectedMode}
            zoyaName={settings.zoyaName}
            userName={settings.userName}
            onAvatarClick={onStartVoice}
            size="hero"
            onEmotionChange={onEmotionChange}
          />
        </div>

        {/* Floating Spoken Dialogue Caption directly on transparent background without container card */}
        <div className="mt-2.5 w-full max-w-md px-2">
          <div className="flex items-center justify-between mb-1.5 px-2">
            <span
              className={`text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                isSpeaking
                  ? 'text-rose-400 animate-pulse'
                  : currentEmotion === 'caring'
                  ? 'text-rose-300'
                  : 'text-slate-400'
              }`}
            >
              {isSpeaking ? (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>Zoya is talking...</span>
                </>
              ) : currentEmotion === 'caring' ? (
                <>
                  <HeartHandshake className="w-3.5 h-3.5 text-rose-400" />
                  <span>Comforting & Caring</span>
                </>
              ) : (
                <>
                  <Heart className="w-3.5 h-3.5 text-pink-400" />
                  <span>{currentModeInfo.name}</span>
                </>
              )}
            </span>

            {/* Action Buttons: Stop Speaking or Say Hi */}
            <div className="flex items-center gap-1.5">
              {isSpeaking && onStopSpeech ? (
                <button
                  onClick={onStopSpeech}
                  className="px-2.5 py-1 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[10px] font-semibold border border-rose-500/30 transition-colors flex items-center gap-1 shadow-sm"
                >
                  <VolumeX className="w-3 h-3" /> Stop
                </button>
              ) : onSpeakText ? (
                <button
                  onClick={() => onSpeakText(currentModeInfo.greeting)}
                  className="px-2.5 py-1 rounded-full bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 text-[10px] font-semibold border border-indigo-500/30 transition-colors flex items-center gap-1 shadow-sm"
                  title="Hear Zoya speak aloud"
                >
                  <Volume2 className="w-3 h-3 text-pink-400" /> Say Hi
                </button>
              ) : null}
            </div>
          </div>

          {/* Spoken Text rendered directly with glowing typography, no card box */}
          <p className="text-sm font-medium text-slate-100 leading-relaxed italic drop-shadow-md text-center sm:text-left px-2 py-1">
            "{isSpeaking && currentSpeechText ? currentSpeechText : currentModeInfo.greeting}"
          </p>

          {/* Speaking animated waveform indicator */}
          {isSpeaking && (
            <div className="mt-1 flex items-center justify-center sm:justify-start gap-1 pt-1 text-rose-300">
              <div className="w-1 h-3 bg-rose-400 rounded-full animate-pulse" />
              <div className="w-1 h-5 bg-rose-300 rounded-full animate-pulse delay-75" />
              <div className="w-1 h-2 bg-pink-400 rounded-full animate-pulse delay-150" />
              <div className="w-1 h-4 bg-rose-400 rounded-full animate-pulse delay-100" />
              <span className="text-[10px] font-semibold ml-1.5">Voice audio playing</span>
            </div>
          )}
        </div>

        {/* 3. Wake Word Listening ("Hey Zoya") Switch Dock */}
        <div className="w-full max-w-md mt-3.5 bg-slate-900/80 border border-slate-800/80 rounded-2xl p-3 flex items-center justify-between shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleWakeListening}
              className={`p-2.5 rounded-xl border transition-all ${
                isWakeListening
                  ? 'bg-emerald-500/25 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-950/50 animate-pulse'
                  : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
              }`}
              title={isWakeListening ? 'Turn Wake Listening OFF' : 'Turn Wake Listening ON'}
            >
              <Radio className="w-4 h-4" />
            </button>
            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white tracking-tight">Wake Listening</span>
                <span
                  className={`px-2 py-0.5 rounded text-[9px] font-extrabold tracking-wider ${
                    isWakeListening
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700/50'
                  }`}
                >
                  {isWakeListening ? 'ON • "HEY ZOYA"' : 'OFF'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-tight mt-0.5">
                {isWakeListening
                  ? 'Say "Hey Zoya" anytime to activate voice'
                  : 'Turn ON to call Zoya hands-free'}
              </p>
            </div>
          </div>

          <button
            onClick={onToggleWakeListening}
            className={`relative inline-flex h-6 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              isWakeListening ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
            role="switch"
            aria-checked={isWakeListening}
            title={isWakeListening ? "Disable 'Hey Zoya' listening" : "Enable 'Hey Zoya' listening"}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                isWakeListening ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* 4. Main Push-To-Talk Voice Microphone Button */}
        <div className="mt-3.5 flex items-center gap-2.5 w-full max-w-md justify-center">
          <button
            onClick={onStartVoice}
            className={`w-full py-3.5 px-5 rounded-2xl font-bold text-sm flex items-center justify-center gap-2.5 shadow-xl transition-all active:scale-95 ${
              isListening
                ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 animate-pulse ring-4 ring-emerald-400/30'
                : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white shadow-indigo-500/30'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="w-5 h-5" />
                <span>Stop Listening</span>
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                <span>Tap to Talk with {settings.zoyaName}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 5. Empathetic Support & Conversation Prompts (Specifically supporting low/difficult moments) */}
      <div className="flex flex-col gap-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3.5 backdrop-blur-md">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-rose-400" />
            <span>Feelings & Quick Chat</span>
          </span>
          <button
            onClick={() => onNavigateTab('chat')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
          >
            Full Chat <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          {caringPrompts.map((item, idx) => {
            const Icon = item.icon;
            const isCare = item.tag === 'care';
            return (
              <button
                key={idx}
                onClick={() => onSelectPrompt(item.label)}
                className={`text-left rounded-xl px-3 py-2 text-xs font-medium transition-all duration-200 flex items-center gap-2 active:scale-95 border ${
                  isCare
                    ? 'bg-rose-950/40 hover:bg-rose-900/50 border-rose-500/30 text-rose-200 hover:border-rose-400/50'
                    : 'bg-slate-800/70 hover:bg-slate-700/80 border-slate-700/60 text-slate-200 hover:border-indigo-500/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isCare ? 'text-rose-400' : 'text-indigo-400'}`} />
                <span>"{item.label}"</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6. Expandable Android Tools & Widgets Drawer (Keeps the main screen clean while giving access) */}
      <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl overflow-hidden">
        <button
          onClick={() => setShowToolsDrawer(!showToolsDrawer)}
          className="w-full px-4 py-2.5 flex items-center justify-between text-xs font-semibold text-slate-300 hover:bg-slate-800/50 transition-colors"
        >
          <span className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Android Apps & Live Weather Tools</span>
          </span>
          <ChevronDown
            className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
              showToolsDrawer ? 'rotate-180' : ''
            }`}
          />
        </button>

        {showToolsDrawer && (
          <div className="p-3.5 pt-1 border-t border-slate-800/60 flex flex-col gap-3 animate-fade-in">
            {/* Quick App Launch Strip */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Fast App Launch
                </span>
                <button
                  onClick={() => onNavigateTab('assistant')}
                  className="text-[10px] text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  All Apps →
                </button>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {ANDROID_APPS.slice(0, 5).map((app) => (
                  <button
                    key={app.id}
                    onClick={() => launchAndroidApp(app)}
                    className="flex flex-col items-center gap-1 p-1.5 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all text-center"
                    title={`Open ${app.name}`}
                  >
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-md"
                      style={{ backgroundColor: app.color }}
                    >
                      {app.id === 'youtube' && <PlayCircle className="w-5 h-5" />}
                      {app.id === 'whatsapp' && <MessageCircle className="w-5 h-5" />}
                      {app.id === 'instagram' && <Camera className="w-5 h-5" />}
                      {app.id === 'spotify' && <Music className="w-5 h-5" />}
                      {app.id === 'camera' && <Camera className="w-5 h-5" />}
                    </div>
                    <span className="text-[9px] font-semibold text-slate-300 truncate w-full">
                      {app.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Weather & Clock Details Card */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/60">
              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 text-left">
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                  <span>Android Clock</span>
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                </div>
                <div className="font-mono font-bold text-base text-white">{formattedTimeStr}</div>
                <div className="text-[10px] text-slate-400 truncate">
                  {currentTime.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                </div>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 text-left">
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                  <span>Forecast</span>
                  <button onClick={onRefreshWeather} disabled={isWeatherLoading}>
                    <RefreshCw className={`w-3 h-3 ${isWeatherLoading ? 'animate-spin text-indigo-400' : 'text-slate-400'}`} />
                  </button>
                </div>
                <div className="font-bold text-base text-white">
                  {weather ? `${Math.round(weather.temp)}°C` : '24°C'}
                </div>
                <div className="text-[10px] text-indigo-300 truncate">
                  {weather?.condition || 'Clear Skies'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 7. Thought for Today / Comforting Note */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3.5 flex items-start gap-3 backdrop-blur-md">
        <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 shrink-0 mt-0.5">
          <Heart className="w-4 h-4" />
        </div>
        <div className="flex-1 text-left">
          <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {settings.zoyaName}'s Daily Comfort Note
          </h4>
          <p className="text-xs text-slate-200 mt-1 leading-relaxed">
            {currentModeInfo.quote}
          </p>
        </div>
      </div>

      {/* Download Project & Android APK Modal */}
      {showDownloadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl overflow-hidden text-left flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <FolderArchive className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Download Project & APK Package</h3>
                  <p className="text-[11px] text-slate-400">Complete source code + Android project structure</p>
                </div>
              </div>
              <button
                onClick={() => setShowDownloadModal(false)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This ZIP archive contains everything needed to run, customize, build the native Android APK, or push to GitHub:
            </p>

            <ul className="space-y-1.5 text-xs text-slate-400 pl-2">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span><strong className="text-slate-200">React 18 + Vite Frontend:</strong> Full TypeScript source with anatomical transparent Zoya.</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span><strong className="text-slate-200">Native Android Studio Project:</strong> Complete Gradle build files, Manifest, and icons.</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span><strong className="text-slate-200">Full Assets:</strong> High-res transparent PNGs, audio controller, speech synthesis, and app launchers.</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span><strong className="text-slate-200">APK Build Guide:</strong> Step-by-step instructions for Android Studio and Bubblewrap CLI.</span>
              </li>
            </ul>

            <button
              onClick={handleDownloadProjectZip}
              disabled={isDownloadingZip}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all active:scale-98 disabled:opacity-75"
            >
              {isDownloadingZip ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Preparing & Downloading ZIP...</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  <span>Downloaded Successfully!</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Package ZIP Now (~8.5 MB)</span>
                </>
              )}
            </button>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1.5">
              <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                <span>APK Build Command (inside extracted folder):</span>
              </div>
              <pre className="p-2 rounded bg-slate-900 text-indigo-300 font-mono text-[10px] overflow-x-auto">
cd android && ./gradlew assembleDebug
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
