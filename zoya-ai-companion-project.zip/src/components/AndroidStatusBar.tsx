import React, { useState, useEffect } from 'react';
import { Wifi, Battery, BatteryCharging, Sparkles } from 'lucide-react';
import { getDeviceBatteryInfo } from '../utils/androidActions';

interface AndroidStatusBarProps {
  isListening?: boolean;
  isSpeaking?: boolean;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({ isListening, isSpeaking }) => {
  const [time, setTime] = useState('');
  const [batteryLevel, setBatteryLevel] = useState<number>(88);
  const [isCharging, setIsCharging] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    getDeviceBatteryInfo().then((info) => {
      if (info.supported && info.level !== undefined) {
        setBatteryLevel(info.level);
        setIsCharging(Boolean(info.charging));
      }
    });
  }, []);

  return (
    <header className="w-full bg-[#090D16]/95 backdrop-blur-md px-5 pt-3 pb-2 flex items-center justify-between text-xs text-slate-300 border-b border-slate-800/40 select-none z-50">
      {/* Time & Zoya indicator */}
      <div className="flex items-center gap-2 font-medium tracking-tight text-slate-200">
        <span className="text-[13px] font-semibold">{time || '12:00'}</span>
        {isListening && (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            Listening...
          </span>
        )}
        {isSpeaking && !isListening && (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded-full border border-rose-500/30 animate-pulse">
            <Sparkles className="w-3 h-3 text-rose-400" />
            Speaking...
          </span>
        )}
      </div>

      {/* Android system status icons */}
      <div className="flex items-center gap-2.5 text-slate-400">
        <span className="text-[11px] font-semibold text-slate-300">5G</span>
        <Wifi className="w-3.5 h-3.5 text-slate-300" />
        <div className="flex items-center gap-1">
          <span className="text-[11px] font-medium text-slate-300">{batteryLevel}%</span>
          {isCharging ? (
            <BatteryCharging className="w-4 h-4 text-emerald-400" />
          ) : (
            <Battery className="w-4 h-4 text-slate-300" />
          )}
        </div>
      </div>
    </header>
  );
};
