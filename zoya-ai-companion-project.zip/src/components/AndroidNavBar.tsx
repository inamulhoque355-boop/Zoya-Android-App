import React from 'react';
import { Home, MessageSquare, Wrench, Settings, Mic, MicOff } from 'lucide-react';

export type NavTab = 'home' | 'chat' | 'assistant' | 'settings';

interface AndroidNavBarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isListening: boolean;
  onToggleVoice: () => void;
  unreadCount?: number;
}

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({
  activeTab,
  onSelectTab,
  isListening,
  onToggleVoice,
  unreadCount = 0,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-[#0B101E]/95 backdrop-blur-xl border-t border-slate-800/80 px-3 py-2 z-40 shadow-2xl">
      <div className="flex items-center justify-around relative">
        {/* Home */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 ${
            activeTab === 'home'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Home screen"
        >
          <div className={`p-1 rounded-lg ${activeTab === 'home' ? 'bg-indigo-500/15' : ''}`}>
            <Home className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Home</span>
        </button>

        {/* Chat */}
        <button
          onClick={() => onSelectTab('chat')}
          className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 relative ${
            activeTab === 'chat'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Chat and Voice"
        >
          <div className={`p-1 rounded-lg relative ${activeTab === 'chat' ? 'bg-indigo-500/15' : ''}`}>
            <MessageSquare className="w-5 h-5" />
            {unreadCount > 0 && activeTab !== 'chat' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full animate-ping" />
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Chat</span>
        </button>

        {/* Floating Center Voice Button */}
        <div className="relative -top-5 flex flex-col items-center">
          <button
            onClick={onToggleVoice}
            className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 transform active:scale-95 ${
              isListening
                ? 'bg-rose-600 text-white shadow-rose-600/50 ring-4 ring-rose-500/30 animate-pulse scale-105'
                : 'bg-gradient-to-tr from-indigo-600 to-violet-500 text-white shadow-indigo-500/40 hover:scale-105 ring-2 ring-indigo-400/30'
            }`}
            aria-label={isListening ? 'Stop listening' : 'Start voice conversation'}
          >
            {isListening ? (
              <MicOff className="w-6 h-6 animate-pulse" />
            ) : (
              <Mic className="w-6 h-6" />
            )}
          </button>
          <span className="text-[10px] font-medium text-slate-300 mt-1">
            {isListening ? 'Listening' : 'Talk'}
          </span>
        </div>

        {/* Assistant */}
        <button
          onClick={() => onSelectTab('assistant')}
          className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 ${
            activeTab === 'assistant'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Assistant phone tools"
        >
          <div className={`p-1 rounded-lg ${activeTab === 'assistant' ? 'bg-indigo-500/15' : ''}`}>
            <Wrench className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Assistant</span>
        </button>

        {/* Settings */}
        <button
          onClick={() => onSelectTab('settings')}
          className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 ${
            activeTab === 'settings'
              ? 'text-indigo-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
          aria-label="Settings"
        >
          <div className={`p-1 rounded-lg ${activeTab === 'settings' ? 'bg-indigo-500/15' : ''}`}>
            <Settings className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Settings</span>
        </button>
      </div>

      {/* Android Gesture Bar */}
      <div className="w-32 h-1 bg-slate-700/60 rounded-full mx-auto mt-2 opacity-80" />
    </nav>
  );
};
