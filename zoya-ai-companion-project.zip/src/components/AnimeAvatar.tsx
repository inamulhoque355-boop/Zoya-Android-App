import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { EmotionType, CompanionMode } from '../types';
import {
  Mic,
  Volume2,
  Sparkles,
  Heart,
  HeartHandshake,
  Smile,
  Frown,
  AlertCircle,
  Flame,
  Coffee,
  HelpCircle,
} from 'lucide-react';
import { speechController } from '../utils/speech';

interface AnimeAvatarProps {
  isSpeaking: boolean;
  isListening: boolean;
  isThinking: boolean;
  currentEmotion: EmotionType;
  mode: CompanionMode;
  zoyaName: string;
  userName: string;
  onAvatarClick?: () => void;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  onEmotionChange?: (emotion: EmotionType) => void;
}

export const AnimeAvatar: React.FC<AnimeAvatarProps> = ({
  isSpeaking,
  isListening,
  isThinking,
  currentEmotion = 'caring',
  mode = 'girlfriend',
  zoyaName = 'Zoya',
  userName = 'Inamul',
  onAvatarClick,
  size = 'hero',
  onEmotionChange,
}) => {
  // Blinking state
  const [isBlinking, setIsBlinking] = useState(false);
  // Mouth viseme index:
  // 0: Closed / syllable pause
  // 1: Small conversational open
  // 2: Wide open 'Ah' / vowel
  // 3: Round 'Oh' / 'U'
  // 4: Smile open 'Ee' / 'Ai'
  const [visemeIndex, setVisemeIndex] = useState<number>(0);
  // Reactive blush boost on click or emotional triggers
  const [blushBoost, setBlushBoost] = useState<boolean>(false);
  // Floating click hearts
  const [hearts, setHearts] = useState<Array<{ id: number; x: number; y: number }>>([]);
  // Audio intensity modulation simulation
  const [audioPulse, setAudioPulse] = useState<number>(1);
  // Interactive gesture wave / greeting trigger
  const [isGesturing, setIsGesturing] = useState(false);

  const isCaringOrEmpathy =
    currentEmotion === 'caring' ||
    currentEmotion === 'empathy' ||
    currentEmotion === 'supportive';

  const isRomantic =
    mode === 'girlfriend' ||
    currentEmotion === 'loving' ||
    currentEmotion === 'shyness';

  // 1. Natural Organic Blinking Engine (2.8s - 4.2s interval with occasional natural double-blink)
  useEffect(() => {
    let blinkTimer: any;
    const triggerBlink = () => {
      setIsBlinking(true);
      setTimeout(() => {
        setIsBlinking(false);
        // 20% chance of a quick, sweet double-blink
        if (Math.random() < 0.2) {
          setTimeout(() => {
            setIsBlinking(true);
            setTimeout(() => setIsBlinking(false), 85);
          }, 120);
        }
      }, 100);

      const nextInterval =
        currentEmotion === 'fear' || currentEmotion === 'surprise'
          ? 1800 + Math.random() * 1400
          : isCaringOrEmpathy
          ? 3200 + Math.random() * 2000
          : 2700 + Math.random() * 1800;

      blinkTimer = setTimeout(triggerBlink, nextInterval);
    };

    blinkTimer = setTimeout(triggerBlink, 2000);
    return () => clearTimeout(blinkTimer);
  }, [currentEmotion, isCaringOrEmpathy]);

  // 2. Synchronized Real-Time Speech & Syllable/Viseme Engine
  useEffect(() => {
    if (!isSpeaking) {
      setVisemeIndex(0);
      setAudioPulse(1);
      return;
    }

    // Dynamic viseme sequence mimicking natural human syllable articulation
    const visemes = isCaringOrEmpathy
      ? [1, 2, 4, 1, 0, 2, 3, 1, 4, 0, 1, 2]
      : [1, 2, 4, 3, 1, 0, 2, 4, 1, 3, 2, 0];

    let step = 0;
    const speedMs = isCaringOrEmpathy ? 115 : 95;

    const interval = setInterval(() => {
      setVisemeIndex(visemes[step % visemes.length]);
      setAudioPulse(0.95 + Math.random() * 0.15);
      step++;
    }, speedMs);

    // Synchronize directly with word boundaries from speech synthesis
    const removeBoundary = speechController.onBoundary(() => {
      // Word boundary hits: open mouth wider for emphasis and syllable initiation
      setVisemeIndex(Math.random() > 0.4 ? 2 : 4);
      setAudioPulse(1.18);
    });

    return () => {
      clearInterval(interval);
      removeBoundary();
      setVisemeIndex(0);
      setAudioPulse(1);
    };
  }, [isSpeaking, isCaringOrEmpathy]);

  // Handle avatar interaction (tap to interact / show affection)
  const handleAvatarClick = (e: React.MouseEvent) => {
    if (onAvatarClick) {
      onAvatarClick();
    }

    // Trigger sweet blush and interactive greeting gesture
    setBlushBoost(true);
    setIsGesturing(true);
    setTimeout(() => setBlushBoost(false), 2800);
    setTimeout(() => setIsGesturing(false), 2400);

    // Spawn floating heart particle
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left - 20;
    const y = e.clientY - rect.top - 20;
    const newHeart = { id: Date.now(), x, y };
    setHearts((prev) => [...prev.slice(-4), newHeart]);

    // Haptic feedback
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(35);
    }
  };

  // Full-body stage dimensions ensuring complete head-to-toe visibility
  const containerDimensions = {
    sm: 'w-[180px] h-[320px]',
    md: 'w-[230px] h-[410px]',
    lg: 'w-[280px] h-[500px]',
    hero: 'w-[280px] sm:w-[320px] md:w-[340px] h-[500px] sm:h-[570px] md:h-[610px]',
  }[size];

  // Stage aura & lighting colors matching emotional context
  const getAuraLighting = () => {
    if (isListening) {
      return {
        glow: 'from-emerald-500/35 via-teal-500/20 to-transparent',
        border: 'border-emerald-500/50',
      };
    }
    if (isThinking) {
      return {
        glow: 'from-amber-500/35 via-purple-500/20 to-transparent',
        border: 'border-amber-500/50',
      };
    }

    switch (currentEmotion) {
      case 'caring':
      case 'empathy':
      case 'supportive':
        return {
          glow: 'from-rose-400/40 via-pink-500/25 to-amber-400/15',
          border: 'border-rose-400/50',
        };
      case 'happy':
      case 'excited':
        return {
          glow: 'from-amber-400/40 via-pink-400/25 to-indigo-400/15',
          border: 'border-amber-400/50',
        };
      case 'loving':
      case 'shyness':
        return {
          glow: 'from-pink-500/40 via-rose-400/25 to-purple-500/15',
          border: 'border-pink-500/50',
        };
      case 'sad':
      case 'concern':
        return {
          glow: 'from-blue-500/30 via-indigo-500/20 to-slate-600/15',
          border: 'border-blue-400/40',
        };
      case 'calmness':
        return {
          glow: 'from-teal-400/30 via-cyan-500/20 to-indigo-500/15',
          border: 'border-teal-400/40',
        };
      case 'surprise':
        return {
          glow: 'from-yellow-400/40 via-amber-500/25 to-pink-500/15',
          border: 'border-yellow-400/50',
        };
      case 'anger':
        return {
          glow: 'from-red-500/35 via-rose-600/25 to-orange-500/15',
          border: 'border-red-500/50',
        };
      case 'fear':
        return {
          glow: 'from-purple-500/35 via-slate-600/25 to-indigo-500/15',
          border: 'border-purple-400/40',
        };
      default:
        return {
          glow: 'from-indigo-500/30 via-purple-500/20 to-pink-500/15',
          border: 'border-indigo-400/40',
        };
    }
  };

  const aura = getAuraLighting();

  // Status badge text and icon
  const getStatusBadge = () => {
    if (isListening) {
      return {
        text: 'Listening to you attentively...',
        icon: Mic,
        color: 'text-emerald-300 bg-emerald-950/85 border-emerald-500/40 shadow-emerald-950/50',
      };
    }
    if (isThinking) {
      return {
        text: `${zoyaName} is thinking...`,
        icon: Sparkles,
        color: 'text-amber-300 bg-amber-950/85 border-amber-500/40 shadow-amber-950/50',
      };
    }
    if (isSpeaking) {
      if (isCaringOrEmpathy) {
        return {
          text: `${zoyaName} is talking softly...`,
          icon: HeartHandshake,
          color: 'text-rose-200 bg-rose-950/90 border-rose-400/60 shadow-rose-950/50 animate-pulse',
        };
      }
      return {
        text: `${zoyaName} is talking...`,
        icon: Volume2,
        color: 'text-rose-300 bg-rose-950/85 border-rose-500/40 animate-pulse',
      };
    }

    switch (currentEmotion) {
      case 'caring':
      case 'empathy':
        return {
          text: `Caring & Supportive • Here for you`,
          icon: HeartHandshake,
          color: 'text-rose-200 bg-rose-950/80 border-rose-400/40 shadow-rose-950/40',
        };
      case 'happy':
        return {
          text: `Happy & Cheerful`,
          icon: Smile,
          color: 'text-amber-300 bg-amber-950/80 border-amber-400/40 shadow-amber-950/40',
        };
      case 'excited':
        return {
          text: `Excited & Energetic`,
          icon: Sparkles,
          color: 'text-yellow-300 bg-yellow-950/80 border-yellow-400/40',
        };
      case 'loving':
      case 'shyness':
        return {
          text: `Loving & Affectionate`,
          icon: Heart,
          color: 'text-pink-300 bg-pink-950/80 border-pink-500/40',
        };
      case 'sad':
        return {
          text: `Gentle & Empathetic Comfort`,
          icon: Frown,
          color: 'text-blue-300 bg-blue-950/80 border-blue-400/40',
        };
      case 'concern':
        return {
          text: `Attentive Concern`,
          icon: AlertCircle,
          color: 'text-sky-300 bg-sky-950/80 border-sky-400/40',
        };
      case 'calmness':
        return {
          text: `Calm & Serene`,
          icon: Coffee,
          color: 'text-teal-300 bg-teal-950/80 border-teal-400/40',
        };
      case 'surprise':
        return {
          text: `Surprised & Curious`,
          icon: HelpCircle,
          color: 'text-yellow-300 bg-yellow-950/80 border-yellow-400/40',
        };
      case 'anger':
        return {
          text: `Expressive & Pouting`,
          icon: Flame,
          color: 'text-red-300 bg-red-950/80 border-red-400/40',
        };
      default:
        return {
          text: `${zoyaName} • Companion`,
          icon: Sparkles,
          color: 'text-indigo-300 bg-indigo-950/80 border-indigo-500/30',
        };
    }
  };

  const status = getStatusBadge();
  const StatusIcon = status.icon;

  // Stand upright in one fixed position:
  // - Anchored firmly at feet (transformOrigin: 50% 98%)
  // - No walking, sliding, drifting, bouncing, or moving away from her position
  // - Subtle natural conversational head tilt and upper body breathing
  const getSubtleBodyMotion = () => {
    if (isSpeaking) {
      return {
        // Very subtle conversational head/torso tilt and cadence (under 0.5 deg, under 1px y)
        rotate: [-0.35, 0.45, -0.2, 0.35, 0],
        y: [0, -0.8, 0, -0.5, 0],
        scaleY: [1, 1.005, 1, 1.003, 1],
        duration: 2.0,
      };
    }

    if (isListening) {
      return {
        // Attentive slight inquisitive head tilt while staying firmly in place
        rotate: [0.6, 0.9, 0.6],
        y: [0, -0.4, 0],
        scaleY: [1, 1.004, 1],
        duration: 2.6,
      };
    }

    if (isThinking) {
      return {
        rotate: [0, 0.5, 0],
        y: [0, -0.4, 0],
        scaleY: [1, 1.003, 1],
        duration: 3.0,
      };
    }

    // Idle: serene natural breathing standing gracefully upright
    return {
      rotate: [-0.2, 0.2, -0.2],
      y: [0, -0.5, 0],
      scaleY: [1, 1.004, 1],
      duration: 4.4,
    };
  };

  const bodyMotion = getSubtleBodyMotion();

  // Blush opacity based on emotional state
  const blushOpacity = blushBoost
    ? 0.85
    : isRomantic
    ? 0.72
    : isSpeaking
    ? 0.62
    : currentEmotion === 'happy' || currentEmotion === 'excited'
    ? 0.65
    : 0.38;

  return (
    <div className="relative flex flex-col items-center justify-center select-none w-full max-w-sm mx-auto">
      {/* Interactive floating hearts on click */}
      <AnimatePresence>
        {hearts.map((h) => (
          <motion.div
            key={h.id}
            initial={{ opacity: 1, scale: 0.6, y: 0 }}
            animate={{ opacity: 0, scale: 1.6, y: -90, x: (Math.random() - 0.5) * 60 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.4, ease: 'easeOut' }}
            className="absolute pointer-events-none z-50"
            style={{ left: h.x, top: h.y }}
          >
            <Heart className="w-7 h-7 text-pink-400 fill-pink-400 filter drop-shadow-lg" />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Full-Body Transparent Character Presentation (Zero Container Boxes, Pure Natural Canvas) */}
      <div className={`relative ${containerDimensions} flex items-center justify-center`}>
        {/* Soft Ambient Emotional Aura behind character (organic radial glow directly on app background) */}
        <motion.div
          animate={{
            scale: isSpeaking ? [1, 1.06, 1] : isListening ? [1, 1.04, 1] : [1, 1.02, 1],
            opacity: isSpeaking ? [0.55, 0.8, 0.55] : [0.35, 0.55, 0.35],
          }}
          transition={{
            repeat: Infinity,
            duration: isSpeaking ? 1.8 : 3.8,
            ease: 'easeInOut',
          }}
          className={`absolute w-72 h-72 rounded-full ${aura.glow} blur-3xl -z-10 pointer-events-none`}
        />

        {/* Interactive Full-Body Character Container: Stand upright in fixed position */}
        <motion.div
          onClick={handleAvatarClick}
          whileHover={{ scale: 1.012 }}
          whileTap={{ scale: 0.99 }}
          animate={{
            rotate: bodyMotion.rotate,
            y: bodyMotion.y,
            scaleY: bodyMotion.scaleY,
          }}
          transition={{
            repeat: Infinity,
            duration: bodyMotion.duration,
            ease: 'easeInOut',
          }}
          style={{ transformOrigin: '50% 98%' }}
          className="relative h-full flex items-center justify-center cursor-pointer"
          title={`Tap to interact with ${zoyaName}`}
        >
          {/* Inner Aspect-Ratio Wrapper matching 768x1376 image dimensions 1:1 */}
          <div
            className="relative h-full flex items-center justify-center"
            style={{ aspectRatio: '768 / 1376' }}
          >
            {/* Full-Body Anime Girl Character Asset */}
            <img
              src="/zoya_full_body.png"
              alt={`${zoyaName} Anime Full Body`}
              className="w-full h-full object-contain object-bottom select-none pointer-events-none drop-shadow-2xl"
              referrerPolicy="no-referrer"
              loading="eager"
            />

            {/* Mathematical Vector Overlay SVG: Exact 768x1376 coordinate space matching character geometry */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none select-none"
              viewBox="0 0 768 1376"
              preserveAspectRatio="xMidYMid meet"
            >
              <defs>
                {/* Cheek Anime Blush Gradient */}
                <radialGradient id="animeBlushGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#FB7185" stopOpacity="0.75" />
                  <stop offset="40%" stopColor="#FDA4AF" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#FDA4AF" stopOpacity="0.0" />
                </radialGradient>

                {/* Acoustic Sound Wave Aura for Speech */}
                <radialGradient id="voiceRippleGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#FDA4AF" stopOpacity="0.5" />
                  <stop offset="70%" stopColor="#FB7185" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#F43F5E" stopOpacity="0" />
                </radialGradient>
              </defs>

              {/* ------------------------------------------------------------- */}
              {/* FACIAL LAYER 1: Dynamic Anime Cheek Blush */}
              {/* ------------------------------------------------------------- */}
              <g id="anime-blush-layer" style={{ opacity: blushOpacity, transition: 'opacity 0.4s ease' }}>
                <ellipse cx="295" cy="218" rx="22" ry="12" fill="url(#animeBlushGrad)" />
                <ellipse cx="480" cy="218" rx="22" ry="12" fill="url(#animeBlushGrad)" />
                {/* Delicate cute anime diagonal blush dashes */}
                {blushBoost && (
                  <>
                    <line x1="288" y1="214" x2="294" y2="222" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
                    <line x1="296" y1="214" x2="302" y2="222" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
                    <line x1="472" y1="214" x2="478" y2="222" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
                    <line x1="480" y1="214" x2="486" y2="222" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
                  </>
                )}
              </g>

              {/* ------------------------------------------------------------- */}
              {/* FACIAL LAYER 2: Dynamic Eyebrow Emotional Expressions */}
              {/* ------------------------------------------------------------- */}
              {isCaringOrEmpathy && (
                <g id="caring-eyebrows" opacity="0.85">
                  {/* Compassionate, softly raised inner brows expressing tender care */}
                  <path d="M 308 156 Q 326 146 345 148" fill="none" stroke="#2B1F33" strokeWidth="2.8" strokeLinecap="round" />
                  <path d="M 430 148 Q 448 146 466 156" fill="none" stroke="#2B1F33" strokeWidth="2.8" strokeLinecap="round" />
                </g>
              )}

              {/* ------------------------------------------------------------- */}
              {/* FACIAL LAYER 3: Organic Blinking Eyelids */}
              {/* ------------------------------------------------------------- */}
              {isBlinking && (
                <g id="blinking-eyelids">
                  {/* Left Eye Eyelid Cover (viewer left) */}
                  <ellipse cx="325" cy="183" rx="19" ry="9" fill="#F5C3AA" />
                  <path d="M 307 184 Q 325 194 343 185" fill="none" stroke="#261A2D" strokeWidth="3.4" strokeLinecap="round" />
                  <path d="M 312 181 Q 325 186 338 182" fill="none" stroke="#A86F5D" strokeWidth="1.2" strokeLinecap="round" />

                  {/* Right Eye Eyelid Cover (viewer right) */}
                  <ellipse cx="450" cy="181" rx="19" ry="9" fill="#F5C3AA" />
                  <path d="M 432 183 Q 450 193 468 184" fill="none" stroke="#261A2D" strokeWidth="3.4" strokeLinecap="round" />
                  <path d="M 437 179 Q 450 185 463 181" fill="none" stroke="#A86F5D" strokeWidth="1.2" strokeLinecap="round" />
                </g>
              )}

              {/* ------------------------------------------------------------- */}
              {/* FACIAL LAYER 4: Acoustic Voice Waves Radiating from Lips */}
              {/* ------------------------------------------------------------- */}
              {isSpeaking && (
                <g id="acoustic-speech-ripples">
                  {/* Subtle radiating sound wave ripples from mouth center (387.5, 232) */}
                  <motion.circle
                    cx="387.5"
                    cy="232"
                    r="16"
                    fill="url(#voiceRippleGrad)"
                    stroke="#FDA4AF"
                    strokeWidth="1.2"
                    initial={{ r: 12, opacity: 0.8 }}
                    animate={{ r: 36, opacity: 0 }}
                    transition={{ repeat: Infinity, duration: 1.1, ease: 'easeOut' }}
                  />
                  <motion.circle
                    cx="387.5"
                    cy="232"
                    r="20"
                    fill="none"
                    stroke="#F472B6"
                    strokeWidth="1.0"
                    initial={{ r: 18, opacity: 0.6 }}
                    animate={{ r: 48, opacity: 0 }}
                    transition={{ repeat: Infinity, duration: 1.1, delay: 0.35, ease: 'easeOut' }}
                  />

                  {/* Micro speech sparkles floating near lips */}
                  <motion.path
                    d="M 416 222 Q 418 224 420 224 Q 418 224 416 226 Q 414 224 412 224 Q 414 224 416 222 Z"
                    fill="#FDE047"
                    animate={{ scale: [0.6, 1.2, 0.6], opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 0.8 }}
                  />
                  <motion.path
                    d="M 358 225 Q 360 227 362 227 Q 360 227 358 229 Q 356 227 354 227 Q 356 227 358 225 Z"
                    fill="#F472B6"
                    animate={{ scale: [0.7, 1.3, 0.7], opacity: [0.4, 0.9, 0.4] }}
                    transition={{ repeat: Infinity, duration: 0.9, delay: 0.2 }}
                  />
                </g>
              )}

              {/* ------------------------------------------------------------- */}
              {/* FACIAL LAYER 5: Synchronized Real-Time Speaking Mouth & Lips */}
              {/* Anatomically and mathematically anchored to Zoya's face at (387.5, 232) */}
              {/* ------------------------------------------------------------- */}
              {isSpeaking && (
                <g id="synchronized-speaking-mouth" transform={`scale(${audioPulse})`} style={{ transformOrigin: '387.5px 232px', transition: 'transform 0.08s ease-out' }}>
                  {/* Soft skin blend under mouth overlay matching exact facial skin tone */}
                  <ellipse cx="387.5" cy="232" rx="17" ry="7.5" fill="#F5C7AD" opacity="0.96" />

                  {/* Viseme 2: Wide Open 'Ah' (vowels and emphasized words) */}
                  {visemeIndex === 2 && (
                    <g id="mouth-viseme-wide-open">
                      {/* Oral Cavity */}
                      <path
                        d="M 372 230 Q 387.5 228 403 230 Q 400 241 387.5 242 Q 375 241 372 230 Z"
                        fill="#4C0519"
                        stroke="#881337"
                        strokeWidth="1.4"
                      />
                      {/* Pearl White Teeth Edge */}
                      <path
                        d="M 375 230 Q 387.5 229 400 230 Q 397 233 387.5 233 Q 378 233 375 230 Z"
                        fill="#FFFFFF"
                      />
                      {/* Soft Pink Tongue Tip */}
                      <ellipse cx="387.5" cy="238.5" rx="6.5" ry="3" fill="#FB7185" />
                      {/* Cupid's Bow Upper Lip Accent */}
                      <path
                        d="M 371 230 Q 379 228.5 387.5 230 Q 396 228.5 404 230"
                        fill="none"
                        stroke="#9F1239"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                      />
                      {/* Lower Lip Warm Glow */}
                      <path
                        d="M 378 243.5 Q 387.5 245 397 243.5"
                        fill="none"
                        stroke="#FDA4AF"
                        strokeWidth="1.3"
                        strokeLinecap="round"
                        opacity="0.8"
                      />
                    </g>
                  )}

                  {/* Viseme 4: Expressive Smiling Open 'Ee' / 'Ai' */}
                  {visemeIndex === 4 && (
                    <g id="mouth-viseme-smile-open">
                      {/* Oral Cavity */}
                      <path
                        d="M 371 230 Q 387.5 231.5 404 230 Q 400 239 387.5 240 Q 375 239 371 230 Z"
                        fill="#4C0519"
                        stroke="#881337"
                        strokeWidth="1.4"
                      />
                      {/* Full Teeth Line */}
                      <path
                        d="M 374 230 Q 387.5 231 401 230 Q 397 233.5 387.5 233.5 Q 378 233.5 374 230 Z"
                        fill="#FFFFFF"
                      />
                      {/* Tongue */}
                      <ellipse cx="387.5" cy="237.5" rx="6" ry="2.2" fill="#FB7185" />
                      {/* Upper Lip Smile Line */}
                      <path
                        d="M 370 230 Q 387.5 231.5 405 230"
                        fill="none"
                        stroke="#9F1239"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      />
                      {/* Lower Lip Line */}
                      <path
                        d="M 378 241.5 Q 387.5 243 397 241.5"
                        fill="none"
                        stroke="#FDA4AF"
                        strokeWidth="1.3"
                        strokeLinecap="round"
                        opacity="0.85"
                      />
                    </g>
                  )}

                  {/* Viseme 3: Rounded 'Oh' / 'U' */}
                  {visemeIndex === 3 && (
                    <g id="mouth-viseme-rounded-o">
                      {/* Rounded Oral Cavity */}
                      <ellipse
                        cx="387.5"
                        cy="232.5"
                        rx="5.5"
                        ry="6.5"
                        fill="#4C0519"
                        stroke="#881337"
                        strokeWidth="1.4"
                      />
                      {/* Tongue */}
                      <ellipse cx="387.5" cy="235" rx="3.5" ry="2" fill="#FB7185" />
                      {/* Upper & Lower Lip Contour */}
                      <path
                        d="M 381 229.5 Q 387.5 228 394 229.5"
                        fill="none"
                        stroke="#9F1239"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                      />
                      <path
                        d="M 383 237.5 Q 387.5 239 392 237.5"
                        fill="none"
                        stroke="#FDA4AF"
                        strokeWidth="1.3"
                        strokeLinecap="round"
                        opacity="0.8"
                      />
                    </g>
                  )}

                  {/* Viseme 1: Small Conversational Open */}
                  {visemeIndex === 1 && (
                    <g id="mouth-viseme-small-open">
                      <path
                        d="M 373 230.5 Q 387.5 229 402 230.5 Q 399 236.5 387.5 237 Q 376 236.5 373 230.5 Z"
                        fill="#5E1224"
                        stroke="#881337"
                        strokeWidth="1.3"
                      />
                      <ellipse cx="387.5" cy="234.5" rx="5" ry="1.8" fill="#FB7185" />
                      <path
                        d="M 372 230.5 Q 379.5 229.5 387.5 230.5 Q 395.5 229.5 403 230.5"
                        fill="none"
                        stroke="#9F1239"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                      />
                      <path
                        d="M 380 238.5 Q 387.5 239.5 395 238.5"
                        fill="none"
                        stroke="#FDA4AF"
                        strokeWidth="1.2"
                        strokeLinecap="round"
                        opacity="0.75"
                      />
                    </g>
                  )}

                  {/* Viseme 0: Closed / Syllable Pause */}
                  {visemeIndex === 0 && (
                    <g id="mouth-viseme-closed">
                      <path
                        d="M 373 232 Q 387.5 233.5 402 232"
                        fill="none"
                        stroke="#9F1239"
                        strokeWidth="1.7"
                        strokeLinecap="round"
                      />
                      <path
                        d="M 383 235 Q 387.5 236 392 235"
                        fill="none"
                        stroke="#FDA4AF"
                        strokeWidth="1.2"
                        strokeLinecap="round"
                        opacity="0.7"
                      />
                    </g>
                  )}
                </g>
              )}
            </svg>

          </div>
        </motion.div>
      </div>

      {/* Live Emotional Status Badge with Speech Equalizer indicator */}
      <div className="mt-2 flex items-center justify-center gap-1.5 z-10">
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold border flex items-center gap-2 shadow-lg backdrop-blur-md transition-all ${status.color}`}
        >
          {isSpeaking ? (
            <div className="flex items-center gap-0.5">
              <div className="w-1 h-3 bg-rose-300 rounded-full animate-pulse" />
              <div className="w-1 h-4.5 bg-rose-200 rounded-full animate-pulse delay-75" />
              <div className="w-1 h-2.5 bg-rose-400 rounded-full animate-pulse delay-150" />
              <div className="w-1 h-4 bg-rose-200 rounded-full animate-pulse delay-100" />
            </div>
          ) : (
            <StatusIcon
              className={`w-3.5 h-3.5 ${isListening ? 'animate-pulse' : ''}`}
            />
          )}
          <span>{status.text}</span>
        </span>
      </div>

      {/* Interactive Emotion Expresser Dock: User can experience Zoya expressing different human emotions */}
      {onEmotionChange && (
        <div className="mt-2.5 w-full flex items-center justify-center gap-1 overflow-x-auto py-1 px-2 no-scrollbar">
          <button
            onClick={() => onEmotionChange('caring')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'caring'
                ? 'bg-rose-500/25 border-rose-400 text-rose-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express caring comfort"
          >
            <HeartHandshake className="w-3 h-3 text-rose-400" /> Caring
          </button>
          <button
            onClick={() => onEmotionChange('happy')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'happy'
                ? 'bg-amber-500/25 border-amber-400 text-amber-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express happiness"
          >
            <Smile className="w-3 h-3 text-amber-400" /> Happy
          </button>
          <button
            onClick={() => onEmotionChange('loving')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'loving'
                ? 'bg-pink-500/25 border-pink-400 text-pink-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express affection & love"
          >
            <Heart className="w-3 h-3 text-pink-400" /> Affection
          </button>
          <button
            onClick={() => onEmotionChange('excited')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'excited'
                ? 'bg-yellow-500/25 border-yellow-400 text-yellow-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express excitement"
          >
            <Sparkles className="w-3 h-3 text-yellow-400" /> Excited
          </button>
          <button
            onClick={() => onEmotionChange('sad')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'sad'
                ? 'bg-blue-500/25 border-blue-400 text-blue-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express empathy for sadness"
          >
            <Frown className="w-3 h-3 text-blue-400" /> Sadness
          </button>
          <button
            onClick={() => onEmotionChange('calmness')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'calmness'
                ? 'bg-teal-500/25 border-teal-400 text-teal-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express calm serenity"
          >
            <Coffee className="w-3 h-3 text-teal-400" /> Calm
          </button>
          <button
            onClick={() => onEmotionChange('shyness')}
            className={`px-2 py-1 rounded-lg text-[10px] font-medium border flex items-center gap-1 transition-all ${
              currentEmotion === 'shyness'
                ? 'bg-rose-500/25 border-rose-400 text-rose-200 shadow-sm'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Express sweet shyness"
          >
            <Sparkles className="w-3 h-3 text-rose-400" /> Shy
          </button>
        </div>
      )}
    </div>
  );
};
